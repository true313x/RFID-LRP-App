package com.arak.rfidlrp.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.arak.rfidlrp.model.Solution

/**
 * تُعرض تسميات المحاور كنصوص Compose عادية خارج مساحة الرسم (Canvas) بدل رسمها داخله،
 * لضمان حجز مساحة كافية لها دون تراكب مع بيانات الرسم على أي حجم شاشة.
 */
@Composable
fun ParetoScatterChart(
    solutions: List<Solution>,
    costAxisLabel: String,
    timeAxisLabel: String,
    modifier: Modifier = Modifier
) {
    Card(modifier = modifier) {
        Column(Modifier.fillMaxSize().padding(10.dp)) {
            Row(Modifier.weight(1f).fillMaxWidth()) {
                RotatedAxisLabel(timeAxisLabel)
                Canvas(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    if (solutions.isEmpty()) return@Canvas
                    val minCost = solutions.minOf { it.totalCost }
                    val maxCost = solutions.maxOf { it.totalCost }
                    val minTime = solutions.minOf { it.totalTime }
                    val maxTime = solutions.maxOf { it.totalTime }
                    val costRange = (maxCost - minCost).takeIf { it > 0 } ?: 1.0
                    val timeRange = (maxTime - minTime).takeIf { it > 0 } ?: 1.0

                    val gridColor = Color(0xFF2C3E50).copy(alpha = 0.25f)
                    for (i in 0..4) {
                        val gy = size.height * i / 4f
                        drawLine(gridColor, Offset(0f, gy), Offset(size.width, gy), strokeWidth = 1f)
                        val gx = size.width * i / 4f
                        drawLine(gridColor, Offset(gx, 0f), Offset(gx, size.height), strokeWidth = 1f)
                    }

                    val sorted = solutions.sortedBy { it.totalCost }
                    for (k in 0 until sorted.size - 1) {
                        val s1 = sorted[k]; val s2 = sorted[k + 1]
                        val x1 = ((s1.totalCost - minCost) / costRange).toFloat() * size.width
                        val y1 = size.height - ((s1.totalTime - minTime) / timeRange).toFloat() * size.height
                        val x2 = ((s2.totalCost - minCost) / costRange).toFloat() * size.width
                        val y2 = size.height - ((s2.totalTime - minTime) / timeRange).toFloat() * size.height
                        drawLine(Color(0xFF90CAF9).copy(alpha = 0.6f), Offset(x1, y1), Offset(x2, y2), strokeWidth = 2f)
                    }

                    solutions.forEach { s ->
                        val px = ((s.totalCost - minCost) / costRange).toFloat() * size.width
                        val py = size.height - ((s.totalTime - minTime) / timeRange).toFloat() * size.height
                        val radius = 5f + (s.trackingEfficiency.toFloat() * 4f)
                        drawCircle(color = Color(0xFF1565C0), radius = radius, center = Offset(px, py))
                        drawCircle(
                            color = Color.White,
                            radius = radius,
                            center = Offset(px, py),
                            style = Stroke(width = 1.2f)
                        )
                    }
                }
            }
            Text(
                costAxisLabel,
                style = MaterialTheme.typography.labelMedium,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
            )
        }
    }
}

@Composable
fun ConvergenceLineChart(
    history: List<Double>,
    xAxisLabel: String,
    modifier: Modifier = Modifier
) {
    Card(modifier = modifier) {
        Column(Modifier.fillMaxSize().padding(10.dp)) {
            Canvas(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (history.size < 2) return@Canvas
                val minV = history.min()
                val maxV = history.max()
                val range = (maxV - minV).takeIf { it > 0 } ?: 1.0

                val gridColor = Color(0xFF2C3E50).copy(alpha = 0.2f)
                for (i in 0..4) {
                    val gy = size.height * i / 4f
                    drawLine(gridColor, Offset(0f, gy), Offset(size.width, gy), strokeWidth = 1f)
                }

                val stepX = size.width / (history.size - 1).coerceAtLeast(1)
                for (k in 0 until history.size - 1) {
                    val x1 = k * stepX
                    val y1 = size.height - ((history[k] - minV) / range).toFloat() * size.height
                    val x2 = (k + 1) * stepX
                    val y2 = size.height - ((history[k + 1] - minV) / range).toFloat() * size.height
                    drawLine(Color(0xFF2E7D32), Offset(x1, y1), Offset(x2, y2), strokeWidth = 2.5f)
                }
            }
            Text(
                xAxisLabel,
                style = MaterialTheme.typography.labelMedium,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
            )
        }
    }
}

@Composable
private fun RotatedAxisLabel(label: String) {
    Box(
        modifier = Modifier.width(20.dp).fillMaxHeight(),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1,
            softWrap = false,
            modifier = Modifier.graphicsLayer { rotationZ = -90f }
        )
    }
}
