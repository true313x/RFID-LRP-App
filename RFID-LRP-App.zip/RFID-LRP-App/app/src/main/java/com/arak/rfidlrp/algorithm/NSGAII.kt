package com.arak.rfidlrp.algorithm

import com.arak.rfidlrp.model.ProblemInstance
import com.arak.rfidlrp.model.Solution
import kotlin.random.Random

/**
 * تطبيق مبسّط لخوارزمية NSGA-II الهجينة الموصوفة في القسم 3-2-8 إلى 3-2-10:
 * ترميز الكروموسوم = مجموعة المرافق المفتوحة، الفرز غير المهيمَن السريع،
 * ومسافة الازدحام (crowding distance) للحفاظ على تنوّع جبهة باريتو.
 */
class NSGAII(
    private val instance: ProblemInstance,
    private val populationSize: Int = 30,
    private val generations: Int = 40,
    private val seed: Long = 7L
) {
    private val rnd = Random(seed)
    private val facilityIds = instance.facilities.map { it.id }

    fun run(onGeneration: (Int, List<Solution>) -> Unit = { _, _ -> }): List<Solution> {
        var population = List(populationSize) { randomChromosome() }
            .map { LRPHeuristics.evaluateSolution(it, instance, rnd) }
            .toMutableList()

        for (gen in 1..generations) {
            val offspring = mutableListOf<Solution>()
            while (offspring.size < populationSize) {
                val p1 = tournamentSelect(population)
                val p2 = tournamentSelect(population)
                val child = mutate(crossover(p1.openFacilities, p2.openFacilities))
                offspring += LRPHeuristics.evaluateSolution(child, instance, rnd)
            }

            val combined = (population + offspring)
            val fronts = fastNonDominatedSort(combined)
            val nextPopulation = mutableListOf<Solution>()
            for (front in fronts) {
                assignCrowdingDistance(front)
                if (nextPopulation.size + front.size <= populationSize) {
                    nextPopulation += front
                } else {
                    nextPopulation += front.sortedByDescending { it.crowdingDistance }
                        .take(populationSize - nextPopulation.size)
                    break
                }
            }
            population = nextPopulation
            onGeneration(gen, population)
        }

        return fastNonDominatedSort(population).first()
    }

    private fun randomChromosome(): Set<Int> {
        val count = rnd.nextInt(2, facilityIds.size + 1)
        return facilityIds.shuffled(rnd).take(count).toSet()
    }

    private fun crossover(a: Set<Int>, b: Set<Int>): Set<Int> {
        val child = facilityIds.filter { id -> if (rnd.nextBoolean()) id in a else id in b }.toSet()
        return if (child.size < 2) randomChromosome() else child
    }

    private fun mutate(chromosome: Set<Int>): Set<Int> {
        val mutationRate = 0.15
        val mutated = chromosome.toMutableSet()
        for (id in facilityIds) {
            if (rnd.nextDouble() < mutationRate) {
                if (id in mutated) mutated.remove(id) else mutated.add(id)
            }
        }
        return if (mutated.size < 2) randomChromosome() else mutated
    }

    private fun dominates(a: Solution, b: Solution): Boolean {
        val notWorse = a.totalCost <= b.totalCost && a.totalTime <= b.totalTime
        val strictlyBetter = a.totalCost < b.totalCost || a.totalTime < b.totalTime
        return notWorse && strictlyBetter
    }

    private fun fastNonDominatedSort(pop: List<Solution>): List<List<Solution>> {
        val fronts = mutableListOf(mutableListOf<Solution>())
        val dominationCount = IntArray(pop.size)
        val dominatedIndices = Array(pop.size) { mutableListOf<Int>() }

        for (i in pop.indices) {
            for (j in pop.indices) {
                if (i == j) continue
                when {
                    dominates(pop[i], pop[j]) -> dominatedIndices[i].add(j)
                    dominates(pop[j], pop[i]) -> dominationCount[i]++
                }
            }
            if (dominationCount[i] == 0) {
                pop[i].rank = 0
                fronts[0].add(pop[i])
            }
        }

        var i = 0
        while (fronts[i].isNotEmpty()) {
            val nextFront = mutableListOf<Solution>()
            for (s in fronts[i]) {
                val sIdx = pop.indexOf(s)
                for (jIdx in dominatedIndices[sIdx]) {
                    dominationCount[jIdx]--
                    if (dominationCount[jIdx] == 0) {
                        pop[jIdx].rank = i + 1
                        nextFront.add(pop[jIdx])
                    }
                }
            }
            i++
            fronts.add(nextFront)
        }
        fronts.removeAt(fronts.size - 1)
        return fronts
    }

    private fun assignCrowdingDistance(front: List<Solution>) {
        if (front.isEmpty()) return
        front.forEach { it.crowdingDistance = 0.0 }
        val selectors = listOf<(Solution) -> Double>({ it.totalCost }, { it.totalTime })
        for (selector in selectors) {
            val sorted = front.sortedBy(selector)
            sorted.first().crowdingDistance = Double.MAX_VALUE
            sorted.last().crowdingDistance = Double.MAX_VALUE
            val minV = selector(sorted.first())
            val maxV = selector(sorted.last())
            val range = (maxV - minV).takeIf { it != 0.0 } ?: 1.0
            for (k in 1 until sorted.size - 1) {
                val prev = selector(sorted[k - 1])
                val next = selector(sorted[k + 1])
                sorted[k].crowdingDistance += (next - prev) / range
            }
        }
    }

    private fun tournamentSelect(pop: List<Solution>): Solution {
        val a = pop[rnd.nextInt(pop.size)]
        val b = pop[rnd.nextInt(pop.size)]
        return when {
            a.rank != b.rank -> if (a.rank < b.rank) a else b
            else -> if (a.crowdingDistance > b.crowdingDistance) a else b
        }
    }
}
