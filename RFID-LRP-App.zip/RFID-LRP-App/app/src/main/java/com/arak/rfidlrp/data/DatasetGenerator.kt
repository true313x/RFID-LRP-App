package com.arak.rfidlrp.data

import com.arak.rfidlrp.model.Customer
import com.arak.rfidlrp.model.Facility
import com.arak.rfidlrp.model.ProblemInstance
import kotlin.random.Random

object DatasetGenerator {

    /**
     * يولّد مجموعة بيانات مطابقة لحالة الأساس الواردة في الفصل الرابع من الأطروحة:
     * 8 مرافق مرشّحة و40 عميلاً، مع سعة مركبة وتكاليف افتراضية.
     */
    fun generateBaseInstance(seed: Long = 42L): ProblemInstance {
        val rnd = Random(seed)

        val facilities = (1..8).map { id ->
            Facility(
                id = id,
                x = rnd.nextDouble(0.0, 100.0),
                y = rnd.nextDouble(0.0, 100.0),
                capacity = rnd.nextInt(80, 150),
                openingCost = rnd.nextDouble(500.0, 1500.0)
            )
        }

        val customers = (1..40).map { id ->
            Customer(
                id = id,
                x = rnd.nextDouble(0.0, 100.0),
                y = rnd.nextDouble(0.0, 100.0),
                demand = rnd.nextInt(5, 20)
            )
        }

        return ProblemInstance(
            facilities = facilities,
            customers = customers,
            vehicleCapacity = 120,
            speed = 1.0,
            serviceTime = 0.5,
            costPerDistance = 2.0,
            rfidCoverageRadius = 35.0,
            rfidSmoothingLambda = 0.30
        )
    }
}
