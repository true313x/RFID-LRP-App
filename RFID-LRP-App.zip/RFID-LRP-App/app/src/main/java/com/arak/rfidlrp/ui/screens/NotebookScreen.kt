package com.arak.rfidlrp.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.arak.rfidlrp.AppViewModel
import com.arak.rfidlrp.ThesisParams
import com.arak.rfidlrp.i18n.LocalAppStrings
import com.arak.rfidlrp.ui.components.AppTopBar
import com.arak.rfidlrp.ui.components.ConvergenceLineChart
import com.arak.rfidlrp.ui.components.ParetoScatterChart

private const val CELL_DATA = """facilities = generate_facilities(n=8, capacity=[80,150], opening_cost=[500,1500])
customers  = generate_customers(n=40, demand=[5,20])
vehicle_capacity      = 120     # Q   (Table 4-3)
rfid_coverage_radius  = 35
rfid_lambda           = 0.30    # RFID smoothing parameter (lambda)"""

private const val CELL_RFID = """def rfid_travel_time(t_base, observed, lam=0.30):
    # Exponential-smoothing update rule (Section 3-2-6)
    return lam * observed + (1 - lam) * t_base

# Outside RFID coverage: reading is missing / noisy -> higher variance
# Section 3-2-7 handles this case explicitly"""

private const val CELL_ALGO = """# Hybrid NSGA-II with Local-Search Refinement (Section 3-2-9)
N, Gmax  = 60, 150        # population size, max generations
pc, pm   = 0.90, 0.05     # crossover / mutation probability
ls_rate  = 0.30           # local-search application rate

P = initialize_population(N)          # Step 1
evaluate(P)                           # Step 2: Z1 (cost), Z2 (RFID time)

g = 0
while g < Gmax and not hypervolume_stalled():
    rank_fronts_and_crowding(P)       # Step 3
    parents = binary_tournament(P)    # Step 4
    Q = crossover_and_mutate(parents, pc, pm)
    local_search_2opt(Q, rate=ls_rate)  # Step 5
    evaluate(Q)
    P = select_best_N(P + Q, N)       # Step 6 (elitism)
    g += 1

pareto_front = front_1(P)"""

private const val CELL_MAIN = """dataset = build_dataset()
front   = run_hybrid_nsga2(dataset, N=60, Gmax=150, pc=0.90, pm=0.05, ls_rate=0.30)

plot_convergence(front.history)
plot_pareto(front.solutions)"""

@Composable
fun NotebookScreen(nav: NavController, vm: AppViewModel) {
    val strings = LocalAppStrings.current
    val isRunning by vm.isRunning.collectAsState()
    val currentGen by vm.currentGeneration.collectAsState()
    val totalGen by vm.totalGenerations.collectAsState()
    val bestCost by vm.bestCostSoFar.collectAsState()
    val pareto by vm.paretoFront.collectAsState()
    val history by vm.generationHistory.collectAsState()
    val elapsedMillis by vm.elapsedMillis.collectAsState()
    val hasRun = history.isNotEmpty() || pareto.isNotEmpty()

    Scaffold(topBar = { AppTopBar(strings.notebookTitle, onBack = { nav.popBackStack() }) }) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            item {
                Text(strings.notebookIntro, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { vm.runOptimization(generations = ThesisParams.DEFAULT_GENERATIONS) },
                    enabled = !isRunning,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (isRunning) {
                        CircularProgressIndicator(
                            modifier = Modifier.height(16.dp).width(16.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp
                        )
                        Text("  " + strings.notebookRunning)
                    } else {
                        Text(strings.notebookRunAll)
                    }
                }
                Spacer(Modifier.height(16.dp))
            }

            item { CodeCell(strings.notebookCellDataTitle, CELL_DATA) }
            item { CodeCell(strings.notebookCellRfidTitle, CELL_RFID) }
            item { CodeCell(strings.notebookCellAlgoTitle, CELL_ALGO) }
            item { CodeCell(strings.notebookCellMainTitle, CELL_MAIN) }

            if (isRunning || hasRun) {
                item {
                    Spacer(Modifier.height(8.dp))
                    Text(strings.notebookOutputTitle, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    OutputConsole(strings, isRunning, currentGen, totalGen, hasRun, elapsedMillis, pareto.size)
                    Spacer(Modifier.height(12.dp))
                }

                if (isRunning) {
                    item {
                        LinearProgressIndicator(
                            progress = { if (totalGen > 0) currentGen.toFloat() / totalGen else 0f },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(16.dp))
                    }
                }

                if (history.size >= 2) {
                    item {
                        Text(strings.notebookConvergenceTitle, style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(8.dp))
                        ConvergenceLineChart(
                            history = history,
                            xAxisLabel = strings.notebookConvergenceAxis,
                            modifier = Modifier.fillMaxWidth().height(200.dp)
                        )
                        Spacer(Modifier.height(16.dp))
                    }
                }

                if (pareto.isNotEmpty()) {
                    item {
                        Text(strings.notebookParetoTitle, style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(8.dp))
                        ParetoScatterChart(
                            solutions = pareto,
                            costAxisLabel = strings.resultsChartCostAxis,
                            timeAxisLabel = strings.resultsChartTimeAxis,
                            modifier = Modifier.fillMaxWidth().height(240.dp)
                        )
                        Spacer(Modifier.height(16.dp))
                    }
                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text(strings.notebookSummaryTitle, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(6.dp))
                                Text(strings.notebookSummarySolutions.format(pareto.size))
                                bestCost?.let { Text(strings.notebookSummaryBestCost.format("%.1f".format(it))) }
                                Text(strings.notebookSummaryTime.format("%.1f".format(elapsedMillis / 1000.0)))
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                    }
                }

                item {
                    Text(
                        strings.notebookEngineNote,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
private fun CodeCell(title: String, code: String) {
    Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(6.dp))
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E2E))
    ) {
        Text(
            code,
            modifier = Modifier.padding(12.dp),
            color = Color(0xFFD4D4E0),
            fontFamily = FontFamily.Monospace,
            style = MaterialTheme.typography.bodySmall
        )
    }
    Spacer(Modifier.height(16.dp))
}

@Composable
private fun OutputConsole(
    strings: com.arak.rfidlrp.i18n.AppStrings,
    isRunning: Boolean,
    currentGen: Int,
    totalGen: Int,
    hasRun: Boolean,
    elapsedMillis: Long,
    solutionCount: Int
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1117))
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(
                strings.notebookLogGenerating,
                color = Color(0xFF8B949E),
                fontFamily = FontFamily.Monospace,
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(4.dp))
            Text(
                strings.notebookLogRunning.format(currentGen.coerceAtLeast(1), totalGen),
                color = Color(0xFF58A6FF),
                fontFamily = FontFamily.Monospace,
                style = MaterialTheme.typography.bodySmall
            )
            if (!isRunning && hasRun) {
                Spacer(Modifier.height(4.dp))
                Text(
                    strings.notebookLogDone.format("%.1f".format(elapsedMillis / 1000.0), solutionCount),
                    color = Color(0xFF3FB950),
                    fontFamily = FontFamily.Monospace,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
