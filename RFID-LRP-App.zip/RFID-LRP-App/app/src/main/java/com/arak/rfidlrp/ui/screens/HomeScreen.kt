package com.arak.rfidlrp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.arak.rfidlrp.AppViewModel
import com.arak.rfidlrp.i18n.AppLanguage
import com.arak.rfidlrp.i18n.LocalAppStrings

@Composable
fun HomeScreen(nav: NavController, vm: AppViewModel) {
    val instance = vm.instance
    val strings = LocalAppStrings.current
    val language by vm.language.collectAsState()

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                AppLanguage.entries.forEach { lang ->
                    FilterChip(
                        selected = lang == language,
                        onClick = { vm.setLanguage(lang) },
                        label = { Text(lang.nativeName) },
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                strings.appTitle,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(strings.appSubtitle, style = MaterialTheme.typography.bodyMedium)

            Spacer(Modifier.height(24.dp))
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(strings.homeDatasetTitle, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("${strings.homeFacilities}: ${instance.facilities.size}")
                    Text("${strings.homeCustomers}: ${instance.customers.size}")
                    Text("${strings.homeVehicleCapacity}: ${instance.vehicleCapacity}")
                    Text("${strings.homeRfidRadius}: ${instance.rfidCoverageRadius.toInt()}")
                }
            }

            Spacer(Modifier.height(24.dp))
            Button(onClick = { nav.navigate("run") }, modifier = Modifier.fillMaxWidth()) {
                Text(strings.homeRunButton)
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { nav.navigate("rfid") }, modifier = Modifier.fillMaxWidth()) {
                Text(strings.homeRfidButton)
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { nav.navigate("about") }, modifier = Modifier.fillMaxWidth()) {
                Text(strings.homeAboutButton)
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { nav.navigate("notebook") }, modifier = Modifier.fillMaxWidth()) {
                Text(strings.homeNotebookButton)
            }
        }
    }
}
