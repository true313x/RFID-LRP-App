package com.arak.rfidlrp.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.arak.rfidlrp.AppViewModel

@Composable
fun HomeScreen(nav: NavController, vm: AppViewModel) {
    val instance = vm.instance

    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(12.dp))
        Text(
            "نظام تتبّع المنتجات بتقنية RFID",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        Text(
            "وحل مشكلة تحديد المواقع وتوجيه المركبات (LRP)",
            style = MaterialTheme.typography.bodyMedium
        )

        Spacer(Modifier.height(24.dp))
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("بيانات المسألة (حالة الأساس)", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("عدد المرافق المرشّحة: ${instance.facilities.size}")
                Text("عدد العملاء: ${instance.customers.size}")
                Text("سعة المركبة: ${instance.vehicleCapacity}")
                Text("نصف قطر تغطية RFID: ${instance.rfidCoverageRadius.toInt()}")
            }
        }

        Spacer(Modifier.height(24.dp))
        Button(onClick = { nav.navigate("run") }, modifier = Modifier.fillMaxWidth()) {
            Text("تشغيل خوارزمية NSGA-II الهجينة")
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = { nav.navigate("rfid") }, modifier = Modifier.fillMaxWidth()) {
            Text("محاكاة قراءات RFID الحيّة")
        }
    }
}
