package com.arak.rfidlrp.algorithm

import com.arak.rfidlrp.model.Customer
import com.arak.rfidlrp.model.Facility
import com.arak.rfidlrp.model.ProblemInstance
import com.arak.rfidlrp.model.Solution
import com.arak.rfidlrp.model.VehicleRoute
import kotlin.random.Random

/**
 * يبني المسارات ويقيّم الحلول وفق الصياغة الرياضية للفصل الثالث:
 * تخصيص العملاء لأقرب مرفق مفتوح، ثم تقسيمهم إلى مسارات مركبات مقيّدة بالسعة.
 */
object LRPHeuristics {

    fun assignCustomersToNearestFacility(
        openFacilities: List<Facility>,
        customers: List<Customer>
    ): Map<Int, Int> {
        val assignment = mutableMapOf<Int, Int>()
        for (c in customers) {
            val nearest = openFacilities.minByOrNull { RFIDSimulator.distance(c.x, c.y, it.x, it.y) }
            if (nearest != null) assignment[c.id] = nearest.id
        }
        return assignment
    }

    fun buildRoutesForFacility(
        facility: Facility,
        assignedCustomers: List<Customer>,
        instance: ProblemInstance,
        rnd: Random
    ): List<VehicleRoute> {
        val remaining = assignedCustomers.toMutableList()
        val routes = mutableListOf<VehicleRoute>()
        var vehicleCounter = 1

        while (remaining.isNotEmpty()) {
            val stops = mutableListOf<Customer>()
            var load = 0
            var currentX = facility.x
            var currentY = facility.y

            while (true) {
                val candidates = remaining.filter { load + it.demand <= instance.vehicleCapacity }
                if (candidates.isEmpty()) break
                val next = candidates.minByOrNull { RFIDSimulator.distance(currentX, currentY, it.x, it.y) }!!
                stops.add(next)
                load += next.demand
                currentX = next.x
                currentY = next.y
                remaining.remove(next)
            }

            if (stops.isEmpty()) break

            val (dist, time) = evaluateRoute(facility, stops, instance, rnd)
            routes.add(
                VehicleRoute(
                    vehicleId = vehicleCounter++,
                    facilityId = facility.id,
                    stops = stops.map { it.id },
                    distance = dist,
                    travelTime = time,
                    load = load
                )
            )
        }
        return routes
    }

    private fun evaluateRoute(
        facility: Facility,
        stops: List<Customer>,
        instance: ProblemInstance,
        rnd: Random
    ): Pair<Double, Double> {
        var totalDist = 0.0
        var totalTime = 0.0
        var px = facility.x
        var py = facility.y

        for (c in stops) {
            val d = RFIDSimulator.distance(px, py, c.x, c.y)
            val base = RFIDSimulator.baseTravelTime(d, instance.speed)
            val covered = RFIDSimulator.isWithinCoverage(c.x, c.y, instance.facilities, instance.rfidCoverageRadius)
            val t = RFIDSimulator.rfidInformedTravelTime(base, covered, rnd) + instance.serviceTime
            totalDist += d
            totalTime += t
            px = c.x
            py = c.y
        }

        val dBack = RFIDSimulator.distance(px, py, facility.x, facility.y)
        totalDist += dBack
        totalTime += RFIDSimulator.baseTravelTime(dBack, instance.speed)
        return totalDist to totalTime
    }

    fun evaluateSolution(openFacilityIds: Set<Int>, instance: ProblemInstance, rnd: Random): Solution {
        val openFacilities = instance.facilities.filter { it.id in openFacilityIds }
        if (openFacilities.isEmpty()) {
            return Solution(emptySet(), emptyMap(), emptyList(), Double.MAX_VALUE, Double.MAX_VALUE, 0.0)
        }

        val assignment = assignCustomersToNearestFacility(openFacilities, instance.customers)
        val allRoutes = mutableListOf<VehicleRoute>()
        for (f in openFacilities) {
            val assigned = instance.customers.filter { assignment[it.id] == f.id }
            allRoutes += buildRoutesForFacility(f, assigned, instance, rnd)
        }

        val openingCost = openFacilities.sumOf { it.openingCost }
        val routingCost = allRoutes.sumOf { it.distance } * instance.costPerDistance
        val totalCost = openingCost + routingCost
        val totalTime = allRoutes.sumOf { it.travelTime }

        val coveredCustomers = instance.customers.count {
            RFIDSimulator.isWithinCoverage(it.x, it.y, openFacilities, instance.rfidCoverageRadius)
        }
        val trackingEfficiency = coveredCustomers.toDouble() / instance.customers.size

        return Solution(
            openFacilities = openFacilityIds,
            assignment = assignment,
            routes = allRoutes,
            totalCost = totalCost,
            totalTime = totalTime,
            trackingEfficiency = trackingEfficiency
        )
    }
}
