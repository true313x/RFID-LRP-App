package com.arak.rfidlrp.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.arak.rfidlrp.AppViewModel

@Composable
fun SolutionDetailScreen(nav: NavController, vm: AppViewModel, index: Int) {
    val pareto by vm.paretoFront.collectAsState()
    val solution = pareto.getOrNull(index)
    val instance = vm.instance

    if (solution == null) {
        Text("الحل غير موجود", modifier = Modifier.padding(20.dp))
        return
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("تفاصيل الحل #${index + 1}", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))

        Canvas(modifier = Modifier.fillMaxWidth().height(260.dp)) {
            val pad = 16f
            val w = size.width - pad * 2
            val h = size.height - pad * 2

            fun mapX(x: Double) = pad + (x / 100.0).toFloat() * w
            fun mapY(y: Double) = size.height - pad - (y / 100.0).toFloat() * h

            solution.routes.forEach { route ->
                val facility = instance.facilities.first { it.id == route.facilityId }
                var prevX = mapX(facility.x)
                var prevY = mapY(facility.y)
                route.stops.forEach { custId ->
                    val c = instance.customers.first { it.id == custId }
                    val cx = mapX(c.x)
                    val cy = mapY(c.y)
                    drawLine(Color(0xFF90A4AE), Offset(prevX, prevY), Offset(cx, cy), strokeWidth = 3f)
                    prevX = cx
                    prevY = cy
                }
                drawLine(
                    Color(0xFF90A4AE),
                    Offset(prevX, prevY),
                    Offset(mapX(facility.x), mapY(facility.y)),
                    strokeWidth = 3f
                )
            }

            instance.customers.forEach { c ->
                val assigned = solution.assignment[c.id] != null
                drawCircle(
                    color = if (assigned) Color(0xFF2E7D32) else Color(0xFFBDBDBD),
                    radius = 5f,
                    center = Offset(mapX(c.x), mapY(c.y))
                )
            }

            instance.facilities.forEach { f ->
                val isOpen = f.id in solution.openFacilities
                drawCircle(
                    color = if (isOpen) Color(0xFFD32F2F) else Color(0xFFE0E0E0),
                    radius = 9f,
                    center = Offset(mapX(f.x), mapY(f.y))
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        Text(
            "التكلفة: ${"%.1f".format(solution.totalCost)}  •  الزمن: ${"%.1f".format(solution.totalTime)}  •  " +
                "تتبّع RFID: ${"%.0f".format(solution.trackingEfficiency * 100)}%"
        )
        Spacer(Modifier.height(8.dp))
        Text("المسارات (${solution.routes.size}):", style = MaterialTheme.typography.titleSmall)

        LazyColumn(Modifier.fillMaxSize()) {
            items(solution.routes.size) { i ->
                val r = solution.routes[i]
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text("مركبة #${r.vehicleId} — من المرفق #${r.facilityId}")
                        Text("التسلسل: ${r.stops.joinToString(" → ")}")
                        Text("الحمولة: ${r.load} • المسافة: ${"%.1f".format(r.distance)} • الزمن: ${"%.1f".format(r.travelTime)}")
                    }
                }
            }
        }
    }
}
