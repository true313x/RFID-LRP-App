package com.arak.rfidlrp.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.arak.rfidlrp.AppViewModel
import com.arak.rfidlrp.i18n.LocalAppStrings
import com.arak.rfidlrp.ui.components.AppTopBar
import androidx.compose.foundation.background

@Composable
fun SolutionDetailScreen(nav: NavController, vm: AppViewModel, index: Int) {
    val strings = LocalAppStrings.current
    val pareto by vm.paretoFront.collectAsState()
    val solution = pareto.getOrNull(index)
    val instance = vm.instance

    Scaffold(topBar = { AppTopBar(strings.detailTitle.format(index + 1), onBack = { nav.popBackStack() }) }) { padding ->
        if (solution == null) {
            Text(strings.detailNotFound, modifier = Modifier.padding(padding).padding(20.dp))
            return@Scaffold
        }

        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Card(Modifier.fillMaxWidth()) {
                Canvas(modifier = Modifier.fillMaxWidth().height(260.dp).padding(8.dp)) {
                    val pad = 16f
                    val w = size.width - pad * 2
                    val h = size.height - pad * 2

                    fun mapX(x: Double) = pad + (x / 100.0).toFloat() * w
                    fun mapY(y: Double) = pad + h - (y / 100.0).toFloat() * h

                    val gridColor = Color(0xFF2C3E50).copy(alpha = 0.15f)
                    for (i in 0..4) {
                        val gy = pad + h * i / 4f
                        drawLine(gridColor, Offset(pad, gy), Offset(pad + w, gy), strokeWidth = 1f)
                        val gx = pad + w * i / 4f
                        drawLine(gridColor, Offset(gx, pad), Offset(gx, pad + h), strokeWidth = 1f)
                    }

                    val routeColors = listOf(
                        Color(0xFF1E88E5), Color(0xFF43A047), Color(0xFFFB8C00),
                        Color(0xFF8E24AA), Color(0xFF00838F), Color(0xFFD81B60)
                    )

                    solution.routes.forEachIndexed { idx, route ->
                        val color = routeColors[idx % routeColors.size]
                        val facility = instance.facilities.first { it.id == route.facilityId }
                        var prevX = mapX(facility.x)
                        var prevY = mapY(facility.y)
                        route.stops.forEach { custId ->
                            val c = instance.customers.first { it.id == custId }
                            val cx = mapX(c.x)
                            val cy = mapY(c.y)
                            drawLine(color.copy(alpha = 0.8f), Offset(prevX, prevY), Offset(cx, cy), strokeWidth = 3f)
                            prevX = cx
                            prevY = cy
                        }
                        drawLine(
                            color.copy(alpha = 0.8f),
                            Offset(prevX, prevY),
                            Offset(mapX(facility.x), mapY(facility.y)),
                            strokeWidth = 3f
                        )
                    }

                    instance.customers.forEach { c ->
                        val assigned = solution.assignment[c.id] != null
                        drawCircle(
                            color = if (assigned) Color(0xFF2E7D32) else Color(0xFFBDBDBD),
                            radius = 5f,
                            center = Offset(mapX(c.x), mapY(c.y))
                        )
                    }

                    instance.facilities.forEach { f ->
                        val isOpen = f.id in solution.openFacilities
                        drawCircle(
                            color = if (isOpen) Color(0xFFD32F2F) else Color(0xFFE0E0E0),
                            radius = 9f,
                            center = Offset(mapX(f.x), mapY(f.y))
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 9f,
                            center = Offset(mapX(f.x), mapY(f.y)),
                            style = Stroke(width = 1.5f)
                        )
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            LegendRow(strings.detailLegendOpen, Color(0xFFD32F2F), strings.detailLegendClosed, Color(0xFFE0E0E0))
            Spacer(Modifier.height(4.dp))
            LegendRow(strings.detailLegendAssigned, Color(0xFF2E7D32), strings.detailLegendUnassigned, Color(0xFFBDBDBD))

            Spacer(Modifier.height(12.dp))
            Text(
                "${strings.resultsCost.format("%.1f".format(solution.totalCost))}  •  " +
                    "${strings.resultsTime.format("%.1f".format(solution.totalTime))}  •  " +
                    strings.resultsTracking.format("%.0f".format(solution.trackingEfficiency * 100))
            )
            Spacer(Modifier.height(8.dp))
            Text(strings.detailRoutesLabel.format(solution.routes.size), style = MaterialTheme.typography.titleSmall)

            LazyColumn(Modifier.fillMaxSize()) {
                items(solution.routes.size) { i ->
                    val r = solution.routes[i]
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Column(Modifier.padding(10.dp)) {
                            Text(
                                "${strings.detailVehiclePrefix.format(r.vehicleId)} — " +
                                    strings.detailFromFacility.format(r.facilityId),
                                fontWeight = FontWeight.Bold
                            )
                            Text(strings.detailSequence.format(r.stops.joinToString(" → ")))
                            Text(
                                "${strings.detailLoad.format(r.load)} • " +
                                    "${strings.detailDistance.format("%.1f".format(r.distance))} • " +
                                    strings.detailTimeLabel.format("%.1f".format(r.travelTime))
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LegendRow(labelA: String, colorA: Color, labelB: String, colorB: Color) {
    Row(modifier = Modifier.fillMaxWidth()) {
        LegendDot(colorA, labelA)
        Spacer(Modifier.width(16.dp))
        LegendDot(colorB, labelB)
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row {
        androidx.compose.foundation.layout.Box(
            modifier = Modifier
                .size(12.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(Modifier.width(6.dp))
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}
