package com.arak.rfidlrp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.arak.rfidlrp.ui.screens.HomeScreen
import com.arak.rfidlrp.ui.screens.RfidScreen
import com.arak.rfidlrp.ui.screens.ResultsScreen
import com.arak.rfidlrp.ui.screens.RunScreen
import com.arak.rfidlrp.ui.screens.SolutionDetailScreen
import com.arak.rfidlrp.ui.theme.RfidLrpTheme

class MainActivity : ComponentActivity() {

    private val viewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RfidLrpTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()
                    NavHost(navController = navController, startDestination = "home") {
                        composable("home") { HomeScreen(navController, viewModel) }
                        composable("run") { RunScreen(navController, viewModel) }
                        composable("results") { ResultsScreen(navController, viewModel) }
                        composable(
                            "solution/{index}",
                            arguments = listOf(navArgument("index") { type = NavType.IntType })
                        ) { backStackEntry ->
                            val index = backStackEntry.arguments?.getInt("index") ?: 0
                            SolutionDetailScreen(navController, viewModel, index)
                        }
                        composable("rfid") { RfidScreen(navController, viewModel) }
                    }
                }
            }
        }
    }
}
