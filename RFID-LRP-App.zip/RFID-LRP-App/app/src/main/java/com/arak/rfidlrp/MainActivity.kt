package com.arak.rfidlrp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.LayoutDirection
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.arak.rfidlrp.i18n.AppLanguage
import com.arak.rfidlrp.i18n.LocalAppLanguage
import com.arak.rfidlrp.i18n.LocalAppStrings
import com.arak.rfidlrp.i18n.stringsFor
import com.arak.rfidlrp.ui.screens.AboutScreen
import com.arak.rfidlrp.ui.screens.HomeScreen
import com.arak.rfidlrp.ui.screens.NotebookScreen
import com.arak.rfidlrp.ui.screens.RfidScreen
import com.arak.rfidlrp.ui.screens.ResultsScreen
import com.arak.rfidlrp.ui.screens.RunScreen
import com.arak.rfidlrp.ui.screens.SolutionDetailScreen
import com.arak.rfidlrp.ui.theme.RfidLrpTheme
import androidx.compose.ui.platform.LocalLayoutDirection

class MainActivity : ComponentActivity() {

    private val viewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val language by viewModel.language.collectAsState()
            val strings = stringsFor(language)
            val direction = if (language.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

            CompositionLocalProvider(
                LocalAppLanguage provides language,
                LocalAppStrings provides strings,
                LocalLayoutDirection provides direction
            ) {
                RfidLrpTheme {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        val navController = rememberNavController()
                        NavHost(navController = navController, startDestination = "home") {
                            composable("home") { HomeScreen(navController, viewModel) }
                            composable("run") { RunScreen(navController, viewModel) }
                            composable("results") { ResultsScreen(navController, viewModel) }
                            composable(
                                "solution/{index}",
                                arguments = listOf(navArgument("index") { type = NavType.IntType })
                            ) { backStackEntry ->
                                val index = backStackEntry.arguments?.getInt("index") ?: 0
                                SolutionDetailScreen(navController, viewModel, index)
                            }
                            composable("rfid") { RfidScreen(navController, viewModel) }
                            composable("about") { AboutScreen(navController) }
                            composable("notebook") { NotebookScreen(navController, viewModel) }
                        }
                    }
                }
            }
        }
    }
}
