package com.arak.rfidlrp.i18n

import androidx.compose.runtime.compositionLocalOf

data class AppStrings(
    val appTitle: String,
    val appSubtitle: String,
    val chooseLanguage: String,

    // Home
    val homeDatasetTitle: String,
    val homeFacilities: String,
    val homeCustomers: String,
    val homeVehicleCapacity: String,
    val homeRfidRadius: String,
    val homeRunButton: String,
    val homeRfidButton: String,
    val homeAboutButton: String,

    // Run
    val runTitle: String,
    val runGenerationsLabel: String,
    val runStartButton: String,
    val runGenerationOf: String,
    val runBestCostSoFar: String,

    // Results
    val resultsTitle: String,
    val resultsChartTitle: String,
    val resultsChartCostAxis: String,
    val resultsChartTimeAxis: String,
    val resultsCount: String,
    val resultsSolutionPrefix: String,
    val resultsOpenFacilities: String,
    val resultsCost: String,
    val resultsTime: String,
    val resultsTracking: String,

    // Detail
    val detailTitle: String,
    val detailLegendOpen: String,
    val detailLegendClosed: String,
    val detailLegendAssigned: String,
    val detailLegendUnassigned: String,
    val detailRoutesLabel: String,
    val detailVehiclePrefix: String,
    val detailFromFacility: String,
    val detailSequence: String,
    val detailLoad: String,
    val detailDistance: String,
    val detailTimeLabel: String,
    val detailNotFound: String,

    // RFID
    val rfidTitle: String,
    val rfidStart: String,
    val rfidStop: String,
    val rfidAt: String,
    val rfidSignal: String,

    // About / Thesis
    val aboutTitle: String,

    // Common
    val back: String
)

val ArabicStrings = AppStrings(
    appTitle = "نظام تتبّع المنتجات بتقنية RFID",
    appSubtitle = "وحل مشكلة تحديد المواقع وتوجيه المركبات (LRP)",
    chooseLanguage = "اللغة",

    homeDatasetTitle = "بيانات المسألة (حالة الأساس)",
    homeFacilities = "عدد المرافق المرشّحة",
    homeCustomers = "عدد العملاء",
    homeVehicleCapacity = "سعة المركبة",
    homeRfidRadius = "نصف قطر تغطية RFID",
    homeRunButton = "تشغيل خوارزمية NSGA-II الهجينة",
    homeRfidButton = "محاكاة قراءات RFID الحيّة",
    homeAboutButton = "عن الأطروحة (شرح تفصيلي)",

    runTitle = "تشغيل الخوارزمية الجينية متعددة الأهداف (NSGA-II)",
    runGenerationsLabel = "عدد الأجيال",
    runStartButton = "بدء التحسين",
    runGenerationOf = "الجيل %d من %d",
    runBestCostSoFar = "أفضل تكلفة حتى الآن: %s",

    resultsTitle = "النتائج",
    resultsChartTitle = "جبهة باريتو: التكلفة (Z1) مقابل زمن التسليم (Z2)",
    resultsChartCostAxis = "التكلفة الإجمالية",
    resultsChartTimeAxis = "زمن التسليم",
    resultsCount = "عدد الحلول غير المهيمَن عليها: %d",
    resultsSolutionPrefix = "حل رقم %d",
    resultsOpenFacilities = "مرافق مفتوحة: %s",
    resultsCost = "التكلفة الإجمالية (Z1): %s",
    resultsTime = "زمن التسليم (Z2): %s",
    resultsTracking = "كفاءة تتبّع RFID: %s٪",

    detailTitle = "تفاصيل الحل رقم %d",
    detailLegendOpen = "مرفق مفتوح",
    detailLegendClosed = "مرفق مغلق",
    detailLegendAssigned = "عميل مخدوم",
    detailLegendUnassigned = "عميل غير مخدوم",
    detailRoutesLabel = "المسارات (%d)",
    detailVehiclePrefix = "مركبة رقم %d",
    detailFromFacility = "من المرفق رقم %d",
    detailSequence = "التسلسل: %s",
    detailLoad = "الحمولة: %d",
    detailDistance = "المسافة: %s",
    detailTimeLabel = "الزمن: %s",
    detailNotFound = "الحل غير موجود",

    rfidTitle = "محاكاة قراءات RFID الحيّة",
    rfidStart = "بدء المحاكاة",
    rfidStop = "إيقاف المحاكاة",
    rfidAt = "عند: %s",
    rfidSignal = "قوة الإشارة: %d٪  •  %s",

    aboutTitle = "عن الأطروحة",

    back = "رجوع"
)

val PersianStrings = AppStrings(
    appTitle = "سامانه ردیابی محصولات با فناوری RFID",
    appSubtitle = "و حل مسئله مکان‌یابی و مسیریابی وسایل نقلیه (LRP)",
    chooseLanguage = "زبان",

    homeDatasetTitle = "داده‌های مسئله (نمونه پایه)",
    homeFacilities = "تعداد تسهیلات نامزد",
    homeCustomers = "تعداد مشتریان",
    homeVehicleCapacity = "ظرفیت وسیله نقلیه",
    homeRfidRadius = "شعاع پوشش RFID",
    homeRunButton = "اجرای الگوریتم ترکیبی NSGA-II",
    homeRfidButton = "شبیه‌سازی زنده قرائت‌های RFID",
    homeAboutButton = "درباره پایان‌نامه (توضیح کامل)",

    runTitle = "اجرای الگوریتم ژنتیک چندهدفه (NSGA-II)",
    runGenerationsLabel = "تعداد نسل‌ها",
    runStartButton = "شروع بهینه‌سازی",
    runGenerationOf = "نسل %d از %d",
    runBestCostSoFar = "بهترین هزینه تاکنون: %s",

    resultsTitle = "نتایج",
    resultsChartTitle = "جبهه پارتو: هزینه (Z1) در برابر زمان تحویل (Z2)",
    resultsChartCostAxis = "هزینه کل",
    resultsChartTimeAxis = "زمان تحویل",
    resultsCount = "تعداد راه‌حل‌های غیرمغلوب: %d",
    resultsSolutionPrefix = "راه‌حل شماره %d",
    resultsOpenFacilities = "تسهیلات باز: %s",
    resultsCost = "هزینه کل (Z1): %s",
    resultsTime = "زمان تحویل (Z2): %s",
    resultsTracking = "کارایی ردیابی RFID: %s٪",

    detailTitle = "جزئیات راه‌حل شماره %d",
    detailLegendOpen = "تسهیل باز",
    detailLegendClosed = "تسهیل بسته",
    detailLegendAssigned = "مشتری تحت پوشش",
    detailLegendUnassigned = "مشتری بدون پوشش",
    detailRoutesLabel = "مسیرها (%d)",
    detailVehiclePrefix = "وسیله نقلیه شماره %d",
    detailFromFacility = "از تسهیل شماره %d",
    detailSequence = "توالی: %s",
    detailLoad = "بار: %d",
    detailDistance = "مسافت: %s",
    detailTimeLabel = "زمان: %s",
    detailNotFound = "راه‌حل یافت نشد",

    rfidTitle = "شبیه‌سازی زنده قرائت‌های RFID",
    rfidStart = "شروع شبیه‌سازی",
    rfidStop = "توقف شبیه‌سازی",
    rfidAt = "در: %s",
    rfidSignal = "قدرت سیگنال: %d٪  •  %s",

    aboutTitle = "درباره پایان‌نامه",

    back = "بازگشت"
)

val EnglishStrings = AppStrings(
    appTitle = "RFID-Based Product Tracking System",
    appSubtitle = "and Location-Routing Problem (LRP) Solver",
    chooseLanguage = "Language",

    homeDatasetTitle = "Problem Data (Base Instance)",
    homeFacilities = "Candidate facilities",
    homeCustomers = "Customers",
    homeVehicleCapacity = "Vehicle capacity",
    homeRfidRadius = "RFID coverage radius",
    homeRunButton = "Run Hybrid NSGA-II Algorithm",
    homeRfidButton = "Live RFID Read Simulation",
    homeAboutButton = "About the Thesis (Full Explanation)",

    runTitle = "Running Multi-Objective Genetic Algorithm (NSGA-II)",
    runGenerationsLabel = "Number of generations",
    runStartButton = "Start Optimization",
    runGenerationOf = "Generation %d of %d",
    runBestCostSoFar = "Best cost so far: %s",

    resultsTitle = "Results",
    resultsChartTitle = "Pareto Front: Cost (Z1) vs Delivery Time (Z2)",
    resultsChartCostAxis = "Total cost",
    resultsChartTimeAxis = "Delivery time",
    resultsCount = "Non-dominated solutions: %d",
    resultsSolutionPrefix = "Solution #%d",
    resultsOpenFacilities = "Open facilities: %s",
    resultsCost = "Total cost (Z1): %s",
    resultsTime = "Delivery time (Z2): %s",
    resultsTracking = "RFID tracking efficiency: %s%%",

    detailTitle = "Solution #%d Details",
    detailLegendOpen = "Open facility",
    detailLegendClosed = "Closed facility",
    detailLegendAssigned = "Covered customer",
    detailLegendUnassigned = "Uncovered customer",
    detailRoutesLabel = "Routes (%d)",
    detailVehiclePrefix = "Vehicle #%d",
    detailFromFacility = "From facility #%d",
    detailSequence = "Sequence: %s",
    detailLoad = "Load: %d",
    detailDistance = "Distance: %s",
    detailTimeLabel = "Time: %s",
    detailNotFound = "Solution not found",

    rfidTitle = "Live RFID Read Simulation",
    rfidStart = "Start Simulation",
    rfidStop = "Stop Simulation",
    rfidAt = "At: %s",
    rfidSignal = "Signal strength: %d%%  •  %s",

    aboutTitle = "About the Thesis",

    back = "Back"
)

fun stringsFor(language: AppLanguage): AppStrings = when (language) {
    AppLanguage.ARABIC -> ArabicStrings
    AppLanguage.PERSIAN -> PersianStrings
    AppLanguage.ENGLISH -> EnglishStrings
}

val LocalAppStrings = compositionLocalOf { ArabicStrings }
val LocalAppLanguage = compositionLocalOf { AppLanguage.ARABIC }
