package com.arak.rfidlrp

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.arak.rfidlrp.algorithm.NSGAII
import com.arak.rfidlrp.algorithm.RFIDSimulator
import com.arak.rfidlrp.data.DatasetGenerator
import com.arak.rfidlrp.model.ProblemInstance
import com.arak.rfidlrp.model.RfidEvent
import com.arak.rfidlrp.model.Solution
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random

class AppViewModel : ViewModel() {

    val instance: ProblemInstance = DatasetGenerator.generateBaseInstance()

    private val _currentGeneration = MutableStateFlow(0)
    val currentGeneration: StateFlow<Int> = _currentGeneration.asStateFlow()

    private val _totalGenerations = MutableStateFlow(40)
    val totalGenerations: StateFlow<Int> = _totalGenerations.asStateFlow()

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private val _paretoFront = MutableStateFlow<List<Solution>>(emptyList())
    val paretoFront: StateFlow<List<Solution>> = _paretoFront.asStateFlow()

    private val _bestCostSoFar = MutableStateFlow<Double?>(null)
    val bestCostSoFar: StateFlow<Double?> = _bestCostSoFar.asStateFlow()

    private val _rfidEvents = MutableStateFlow<List<RfidEvent>>(emptyList())
    val rfidEvents: StateFlow<List<RfidEvent>> = _rfidEvents.asStateFlow()

    private val _rfidRunning = MutableStateFlow(false)
    val rfidRunning: StateFlow<Boolean> = _rfidRunning.asStateFlow()

    fun runOptimization(generations: Int = 40, populationSize: Int = 30) {
        if (_isRunning.value) return
        _totalGenerations.value = generations
        _isRunning.value = true
        _currentGeneration.value = 0
        _paretoFront.value = emptyList()

        viewModelScope.launch {
            val result = withContext(Dispatchers.Default) {
                val ga = NSGAII(instance, populationSize = populationSize, generations = generations)
                ga.run { gen, population ->
                    _currentGeneration.value = gen
                    _bestCostSoFar.value = population.minOf { it.totalCost }
                }
            }
            _paretoFront.value = result.sortedBy { it.totalCost }
            _isRunning.value = false
        }
    }

    fun toggleRfidSimulation() {
        if (_rfidRunning.value) {
            _rfidRunning.value = false
            return
        }
        _rfidRunning.value = true
        viewModelScope.launch(Dispatchers.Default) {
            val rnd = Random(System.currentTimeMillis())
            while (isActive && _rfidRunning.value) {
                val event = RFIDSimulator.generateLiveEvent(instance, rnd)
                _rfidEvents.value = (listOf(event) + _rfidEvents.value).take(50)
                delay(900)
            }
        }
    }
}
