package com.arak.rfidlrp

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.arak.rfidlrp.algorithm.NSGAII
import com.arak.rfidlrp.algorithm.RFIDSimulator
import com.arak.rfidlrp.data.DatasetGenerator
import com.arak.rfidlrp.i18n.AppLanguage
import com.arak.rfidlrp.model.ProblemInstance
import com.arak.rfidlrp.model.RfidEvent
import com.arak.rfidlrp.model.Solution
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random

private const val PREFS_NAME = "rfid_lrp_prefs"
private const val KEY_LANGUAGE = "language_code"

/** معاملات الخوارزمية المطابقة لجدول 4-3 في الأطروحة. */
object ThesisParams {
    const val POPULATION_SIZE = 60
    const val DEFAULT_GENERATIONS = 150
    const val CROSSOVER_PROBABILITY = 0.90
    const val MUTATION_PROBABILITY = 0.05
    const val LOCAL_SEARCH_RATE = 0.30
    const val RFID_LAMBDA = 0.30
}

class AppViewModel(application: Application) : AndroidViewModel(application) {

    val instance: ProblemInstance = DatasetGenerator.generateBaseInstance()

    private val prefs = application.getSharedPreferences(PREFS_NAME, Application.MODE_PRIVATE)

    private val _language = MutableStateFlow(
        AppLanguage.fromCode(prefs.getString(KEY_LANGUAGE, AppLanguage.ARABIC.code))
    )
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    fun setLanguage(lang: AppLanguage) {
        _language.value = lang
        prefs.edit().putString(KEY_LANGUAGE, lang.code).apply()
    }

    private val _currentGeneration = MutableStateFlow(0)
    val currentGeneration: StateFlow<Int> = _currentGeneration.asStateFlow()

    private val _totalGenerations = MutableStateFlow(ThesisParams.DEFAULT_GENERATIONS)
    val totalGenerations: StateFlow<Int> = _totalGenerations.asStateFlow()

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private val _paretoFront = MutableStateFlow<List<Solution>>(emptyList())
    val paretoFront: StateFlow<List<Solution>> = _paretoFront.asStateFlow()

    private val _bestCostSoFar = MutableStateFlow<Double?>(null)
    val bestCostSoFar: StateFlow<Double?> = _bestCostSoFar.asStateFlow()

    private val _generationHistory = MutableStateFlow<List<Double>>(emptyList())
    val generationHistory: StateFlow<List<Double>> = _generationHistory.asStateFlow()

    private val _elapsedMillis = MutableStateFlow(0L)
    val elapsedMillis: StateFlow<Long> = _elapsedMillis.asStateFlow()

    private val _rfidEvents = MutableStateFlow<List<RfidEvent>>(emptyList())
    val rfidEvents: StateFlow<List<RfidEvent>> = _rfidEvents.asStateFlow()

    private val _rfidRunning = MutableStateFlow(false)
    val rfidRunning: StateFlow<Boolean> = _rfidRunning.asStateFlow()

    fun runOptimization(
        generations: Int = ThesisParams.DEFAULT_GENERATIONS,
        populationSize: Int = ThesisParams.POPULATION_SIZE
    ) {
        if (_isRunning.value) return
        _totalGenerations.value = generations
        _isRunning.value = true
        _currentGeneration.value = 0
        _paretoFront.value = emptyList()
        _generationHistory.value = emptyList()
        _elapsedMillis.value = 0L
        val startTime = System.currentTimeMillis()

        viewModelScope.launch {
            val result = withContext(Dispatchers.Default) {
                val ga = NSGAII(
                    instance,
                    populationSize = populationSize,
                    generations = generations,
                    crossoverProbability = ThesisParams.CROSSOVER_PROBABILITY,
                    mutationProbability = ThesisParams.MUTATION_PROBABILITY,
                    localSearchRate = ThesisParams.LOCAL_SEARCH_RATE
                )
                ga.run { gen, population ->
                    val best = population.minOf { it.totalCost }
                    _currentGeneration.value = gen
                    _bestCostSoFar.value = best
                    _generationHistory.value = _generationHistory.value + best
                    _elapsedMillis.value = System.currentTimeMillis() - startTime
                }
            }
            _paretoFront.value = result.sortedBy { it.totalCost }
            _elapsedMillis.value = System.currentTimeMillis() - startTime
            _isRunning.value = false
        }
    }

    fun toggleRfidSimulation() {
        if (_rfidRunning.value) {
            _rfidRunning.value = false
            return
        }
        _rfidRunning.value = true
        viewModelScope.launch(Dispatchers.Default) {
            val rnd = Random(System.currentTimeMillis())
            val bestSolution = _paretoFront.value.minByOrNull { it.totalCost }
            while (isActive && _rfidRunning.value) {
                val event = RFIDSimulator.generateLiveEvent(instance, rnd, bestSolution)
                _rfidEvents.value = (listOf(event) + _rfidEvents.value).take(60)
                delay(850)
            }
        }
    }

    fun clearRfidEvents() {
        _rfidEvents.value = emptyList()
    }
}
