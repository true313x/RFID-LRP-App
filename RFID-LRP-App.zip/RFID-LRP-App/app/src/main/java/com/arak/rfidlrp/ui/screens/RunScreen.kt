package com.arak.rfidlrp.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.arak.rfidlrp.AppViewModel
import com.arak.rfidlrp.ThesisParams
import com.arak.rfidlrp.i18n.LocalAppStrings
import com.arak.rfidlrp.ui.components.AppTopBar

@Composable
fun RunScreen(nav: NavController, vm: AppViewModel) {
    val strings = LocalAppStrings.current
    val isRunning by vm.isRunning.collectAsState()
    val currentGen by vm.currentGeneration.collectAsState()
    val totalGen by vm.totalGenerations.collectAsState()
    val bestCost by vm.bestCostSoFar.collectAsState()
    val pareto by vm.paretoFront.collectAsState()
    val elapsedMillis by vm.elapsedMillis.collectAsState()

    var generations by remember { mutableStateOf(ThesisParams.DEFAULT_GENERATIONS.toFloat()) }
    var navigated by remember { mutableStateOf(false) }

    LaunchedEffect(isRunning, pareto) {
        if (!isRunning && pareto.isNotEmpty() && !navigated) {
            navigated = true
            // إزالة شاشة التشغيل من مكدس التنقّل حتى لا يعود زر "رجوع" من شاشة
            // النتائج إليها فيُعاد التوجيه فورًا إلى النتائج من جديد (حلقة لا تنتهي).
            nav.navigate("results") {
                popUpTo("run") { inclusive = true }
                launchSingleTop = true
            }
        }
    }

    Scaffold(topBar = { AppTopBar(strings.runTitle, onBack = { nav.popBackStack() }) }) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(8.dp))

            if (!isRunning) {
                Text("${strings.runGenerationsLabel}: ${generations.toInt()}")
                Slider(
                    value = generations,
                    onValueChange = { generations = it },
                    valueRange = 50f..200f,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                Card(Modifier.fillMaxWidth()) {
                    Text(
                        strings.runParamsNote,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(12.dp)
                    )
                }
                Spacer(Modifier.height(16.dp))
                Button(onClick = { vm.runOptimization(generations = generations.toInt()) }) {
                    Text(strings.runStartButton)
                }
            } else {
                Text(strings.runGenerationOf.format(currentGen, totalGen))
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { if (totalGen > 0) currentGen.toFloat() / totalGen else 0f },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                bestCost?.let { Text(strings.runBestCostSoFar.format("%.1f".format(it))) }
                Spacer(Modifier.height(4.dp))
                Text(strings.runElapsed.format("%.1f".format(elapsedMillis / 1000.0)))
            }
        }
    }
}
