package com.arak.rfidlrp.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.arak.rfidlrp.AppViewModel
import com.arak.rfidlrp.i18n.LocalAppStrings
import com.arak.rfidlrp.ui.components.AppTopBar

@Composable
fun RunScreen(nav: NavController, vm: AppViewModel) {
    val strings = LocalAppStrings.current
    val isRunning by vm.isRunning.collectAsState()
    val currentGen by vm.currentGeneration.collectAsState()
    val totalGen by vm.totalGenerations.collectAsState()
    val bestCost by vm.bestCostSoFar.collectAsState()
    val pareto by vm.paretoFront.collectAsState()

    var generations by remember { mutableStateOf(40f) }
    var navigated by remember { mutableStateOf(false) }

    LaunchedEffect(isRunning, pareto) {
        if (!isRunning && pareto.isNotEmpty() && !navigated) {
            navigated = true
            nav.navigate("results")
        }
    }

    Scaffold(topBar = { AppTopBar(strings.runTitle, onBack = { nav.popBackStack() }) }) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(8.dp))

            if (!isRunning) {
                Text("${strings.runGenerationsLabel}: ${generations.toInt()}")
                Slider(
                    value = generations,
                    onValueChange = { generations = it },
                    valueRange = 10f..100f,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(16.dp))
                Button(onClick = { vm.runOptimization(generations = generations.toInt()) }) {
                    Text(strings.runStartButton)
                }
            } else {
                Text(strings.runGenerationOf.format(currentGen, totalGen))
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { if (totalGen > 0) currentGen.toFloat() / totalGen else 0f },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                bestCost?.let { Text(strings.runBestCostSoFar.format("%.1f".format(it))) }
            }
        }
    }
}
