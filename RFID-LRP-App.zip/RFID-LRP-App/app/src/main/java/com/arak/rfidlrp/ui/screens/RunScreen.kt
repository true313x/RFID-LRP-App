package com.arak.rfidlrp.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.arak.rfidlrp.AppViewModel

@Composable
fun RunScreen(nav: NavController, vm: AppViewModel) {
    val isRunning by vm.isRunning.collectAsState()
    val currentGen by vm.currentGeneration.collectAsState()
    val totalGen by vm.totalGenerations.collectAsState()
    val bestCost by vm.bestCostSoFar.collectAsState()
    val pareto by vm.paretoFront.collectAsState()

    var generations by remember { mutableStateOf(40f) }
    var navigated by remember { mutableStateOf(false) }

    LaunchedEffect(isRunning, pareto) {
        if (!isRunning && pareto.isNotEmpty() && !navigated) {
            navigated = true
            nav.navigate("results")
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("تشغيل الخوارزمية الجينية متعددة الأهداف (NSGA-II)", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(16.dp))

        if (!isRunning) {
            Text("عدد الأجيال: ${generations.toInt()}")
            Slider(
                value = generations,
                onValueChange = { generations = it },
                valueRange = 10f..100f,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = { vm.runOptimization(generations = generations.toInt()) }) {
                Text("بدء التحسين")
            }
        } else {
            Text("الجيل: $currentGen / $totalGen")
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { if (totalGen > 0) currentGen.toFloat() / totalGen else 0f },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            bestCost?.let { Text("أفضل تكلفة حتى الآن: ${"%.1f".format(it)}") }
        }
    }
}
