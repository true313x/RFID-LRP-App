package com.arak.rfidlrp.algorithm

import com.arak.rfidlrp.model.Facility
import com.arak.rfidlrp.model.ProblemInstance
import com.arak.rfidlrp.model.RfidEvent
import kotlin.math.hypot
import kotlin.random.Random

/**
 * يحاكي معمارية جمع بيانات RFID وقاعدة تحديث زمن السفر (القسمان 3-2-5 و3-2-6 من الأطروحة)،
 * بما في ذلك التعامل مع البيانات الناقصة/المشوّشة خارج نطاق التغطية (القسم 3-2-7).
 */
object RFIDSimulator {

    fun distance(x1: Double, y1: Double, x2: Double, y2: Double): Double =
        hypot(x1 - x2, y1 - y2)

    fun baseTravelTime(dist: Double, speed: Double): Double = dist / speed

    fun isWithinCoverage(px: Double, py: Double, facilities: List<Facility>, radius: Double): Boolean =
        facilities.any { distance(px, py, it.x, it.y) <= radius }

    /**
     * زمن سفر "مستنَد إلى RFID": يضيف تباينًا واقعيًا؛ القراءات ضمن نطاق التغطية أدق،
     * بينما خارج النطاق تكون البيانات أكثر تشوشًا (تحاكي فقدان/تأخر إشارات RFID).
     */
    fun rfidInformedTravelTime(baseTime: Double, withinCoverage: Boolean, rnd: Random): Double {
        val noise = if (withinCoverage) rnd.nextDouble(-0.05, 0.10) else rnd.nextDouble(-0.05, 0.35)
        return baseTime * (1.0 + noise)
    }

    fun generateLiveEvent(instance: ProblemInstance, rnd: Random): RfidEvent {
        val label = if (rnd.nextBoolean()) {
            val f = instance.facilities[rnd.nextInt(instance.facilities.size)]
            "مرفق #${f.id}"
        } else {
            val c = instance.customers[rnd.nextInt(instance.customers.size)]
            "عميل #${c.id}"
        }
        return RfidEvent(
            tagId = "TAG-${rnd.nextInt(1000, 9999)}",
            productCode = "PRD-${rnd.nextInt(100, 999)}",
            nodeLabel = label,
            timestampMs = System.currentTimeMillis(),
            signalStrength = rnd.nextInt(40, 100)
        )
    }
}
