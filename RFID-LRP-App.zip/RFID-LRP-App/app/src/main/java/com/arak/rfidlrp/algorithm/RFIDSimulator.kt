package com.arak.rfidlrp.algorithm

import com.arak.rfidlrp.model.Facility
import com.arak.rfidlrp.model.ProblemInstance
import com.arak.rfidlrp.model.RfidEvent
import com.arak.rfidlrp.model.RfidEventType
import com.arak.rfidlrp.model.RfidNodeKind
import kotlin.math.hypot
import kotlin.random.Random

/**
 * يحاكي معمارية جمع بيانات RFID وقاعدة تحديث زمن السفر (القسمان 3-2-5 و3-2-6 من الأطروحة)،
 * بما في ذلك التعامل مع البيانات الناقصة/المشوّشة خارج نطاق التغطية (القسم 3-2-7).
 */
object RFIDSimulator {

    fun distance(x1: Double, y1: Double, x2: Double, y2: Double): Double =
        hypot(x1 - x2, y1 - y2)

    fun baseTravelTime(dist: Double, speed: Double): Double = dist / speed

    fun isWithinCoverage(px: Double, py: Double, facilities: List<Facility>, radius: Double): Boolean =
        facilities.any { distance(px, py, it.x, it.y) <= radius }

    /**
     * زمن سفر "مستنَد إلى RFID": يضيف تباينًا واقعيًا؛ القراءات ضمن نطاق التغطية أدق،
     * بينما خارج النطاق تكون البيانات أكثر تشوشًا. معامل التنعيم الأُسّي λ (القسم 3-2-6 من
     * الأطروحة) يُخفّض تذبذب القراءات كلما اقترب من 1 (تحديث أكثر استقرارًا وأقل ضوضاء).
     */
    fun rfidInformedTravelTime(
        baseTime: Double,
        withinCoverage: Boolean,
        rnd: Random,
        smoothingLambda: Double = 0.30
    ): Double {
        val dampening = (1.0 - smoothingLambda).coerceIn(0.15, 1.0)
        val noise = if (withinCoverage) {
            rnd.nextDouble(-0.05, 0.10) * dampening
        } else {
            rnd.nextDouble(-0.05, 0.35) * dampening
        }
        return baseTime * (1.0 + noise)
    }

    fun generateLiveEvent(
        instance: ProblemInstance,
        rnd: Random,
        solution: com.arak.rfidlrp.model.Solution? = null
    ): RfidEvent {
        val routes = solution?.routes.orEmpty()

        val kind: RfidNodeKind
        val eventType: RfidEventType
        val nodeId: Int
        val vehicleId: Int?
        val px: Double
        val py: Double

        if (routes.isNotEmpty()) {
            val route = routes[rnd.nextInt(routes.size)]
            val facility = instance.facilities.first { it.id == route.facilityId }
            if (route.stops.isEmpty() || rnd.nextInt(4) == 0) {
                kind = RfidNodeKind.FACILITY
                eventType = RfidEventType.PICKUP
                nodeId = facility.id
                vehicleId = route.vehicleId
                px = facility.x; py = facility.y
            } else {
                val custId = route.stops[rnd.nextInt(route.stops.size)]
                val c = instance.customers.first { it.id == custId }
                kind = RfidNodeKind.CUSTOMER
                eventType = RfidEventType.DELIVERY
                nodeId = c.id
                vehicleId = route.vehicleId
                px = c.x; py = c.y
            }
        } else if (rnd.nextBoolean()) {
            val f = instance.facilities[rnd.nextInt(instance.facilities.size)]
            kind = RfidNodeKind.FACILITY
            eventType = RfidEventType.PICKUP
            nodeId = f.id
            vehicleId = null
            px = f.x; py = f.y
        } else {
            val c = instance.customers[rnd.nextInt(instance.customers.size)]
            kind = RfidNodeKind.CUSTOMER
            eventType = RfidEventType.DELIVERY
            nodeId = c.id
            vehicleId = null
            px = c.x; py = c.y
        }

        val nearestDist = instance.facilities.minOf { distance(px, py, it.x, it.y) }
        val coverageRatio = (nearestDist / instance.rfidCoverageRadius).coerceIn(0.0, 2.0)
        val baseSignal = (100 - coverageRatio * 55).coerceIn(25.0, 100.0)
        val signal = (baseSignal + rnd.nextInt(-8, 9)).toInt().coerceIn(15, 100)

        return RfidEvent(
            tagId = "TAG-${rnd.nextInt(1000, 9999)}",
            productCode = "PRD-${rnd.nextInt(100, 999)}",
            eventType = eventType,
            nodeKind = kind,
            nodeId = nodeId,
            vehicleId = vehicleId,
            timestampMs = System.currentTimeMillis(),
            signalStrength = signal
        )
    }
}
