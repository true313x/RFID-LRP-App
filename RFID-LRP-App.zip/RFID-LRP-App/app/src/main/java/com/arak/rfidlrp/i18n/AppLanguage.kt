package com.arak.rfidlrp.i18n

enum class AppLanguage(val code: String, val nativeName: String, val isRtl: Boolean) {
    ARABIC("ar", "العربية", true),
    PERSIAN("fa", "فارسی", true),
    ENGLISH("en", "English", false);

    companion object {
        fun fromCode(code: String?): AppLanguage =
            entries.firstOrNull { it.code == code } ?: ARABIC
    }
}
