package com.arak.rfidlrp.i18n

data class ThesisSection(val heading: String, val body: String)

private val arabicSections = listOf(
    ThesisSection(
        "عنوان الأطروحة",
        "نهج قائم على تقنية RFID وخوارزميات ذكية لتتبّع المنتجات، وحل مسألة تحديد مواقع " +
            "المرافق وتوجيه المركبات (Location-Routing Problem – LRP) في شبكات التوزيع وسلاسل التوريد."
    ),
    ThesisSection(
        "المشكلة البحثية",
        "مع اتساع شبكات التوزيع وتزايد تعقيد سلاسل التوريد، لم تعد قرارات النقل تقتصر على نقل " +
            "المنتجات من المورّد إلى العميل، بل باتت تشمل تحديد مواقع المرافق، وتخصيص العملاء، وتوجيه " +
            "المركبات في آن واحد. غالبية نماذج تحديد المواقع وتوجيه المركبات التقليدية تعتمد على " +
            "تقديرات زمن سفر ثابتة مبنية على المسافة فقط، ولا تُدمَج فيها بيانات التتبّع اللحظي التي " +
            "توفّرها تقنية RFID ضمن عملية اتخاذ القرار. السؤال المركزي: كيف يمكن دمج معلومات تتبّع " +
            "المنتجات المولَّدة عبر RFID مع مسألة تحديد المواقع وتوجيه المركبات متعددة الأهداف، ونهج " +
            "تحسين ذكي، لتحسين التكلفة اللوجستية وكفاءة التتبّع وأداء التسليم؟"
    ),
    ThesisSection(
        "أهمية البحث",
        "تنبع أهمية الدراسة من خمسة أبعاد: علميًا، تربط بين مجالات مستقلة تقليديًا (تحديد الهوية " +
            "عبر RFID، ظهور سلسلة التوريد، تحديد المواقع، توجيه المركبات، التحسين متعدد الأهداف، " +
            "الخوارزميات الذكية). تقنيًا، ترفع القيمة التشغيلية لـRFID بربطها بسلسلة: جمع البيانات ← " +
            "معالجتها ← التحسين ← اتخاذ القرار الذكي. اقتصاديًا، تراعي تكاليف إنشاء المرافق والنقل " +
            "وتشغيل المركبات وتطبيق RFID معًا. إداريًا، توفّر إطار دعم قرار لمديري سلاسل التوريد. " +
            "وحوسبيًا، تستجيب لصعوبة الحل الدقيق لمسألة LRP متعددة الأهداف عبر خوارزميات ذكية."
    ),
    ThesisSection(
        "أهداف البحث",
        "الهدف الرئيسي: بناء إطار تحسين ذكي مفعَّل بتقنية RFID لتتبّع المنتجات وحل مسألة تحديد " +
            "المواقع وتوجيه المركبات متعددة الأهداف. ومن الأهداف الفرعية: دراسة دور RFID في تحسين " +
            "تتبّع المنتجات وظهور سلسلة التوريد؛ تحويل بيانات RFID إلى مدخلات تحسين؛ صياغة نموذج " +
            "رياضي للمسألة؛ تحديد مواقع المرافق وتخصيص العملاء وتوجيه المركبات معًا؛ تقليل التكلفة " +
            "اللوجستية الإجمالية وزمن التسليم مع تعظيم كفاءة التتبّع؛ مراعاة القيود العملية (سعة " +
            "المركبات، سعة المرافق، تغطية RFID)؛ تطوير خوارزمية ذكية/ميتاهيوريستيك للحل؛ وتقييم " +
            "الأداء ومقارنته بأساليب مرجعية عبر سيناريوهات مختلفة."
    ),
    ThesisSection(
        "الأدوات والمنهجية المتّبعة",
        "اعتُمد منهج تحليلي/نمذجي: يُصاغ المسألة كبرنامج رياضي مختلط الأعداد الصحيحة متعدد " +
            "الأهداف، إلى جانب خوارزمية حل مخصّصة. يتكوّن النموذج من ثلاثة عناصر: (1) نموذج رياضي " +
            "يشمل شبكة توزيع ثنائية المستوى (مرافق مرشّحة ← عملاء)، (2) آلية معالجة تحوّل أحداث قراءة " +
            "وسوم RFID الخام إلى معامل \"زمن السفر\" عبر قاعدة تنعيم أُسّي (Exponential Smoothing) " +
            "تُحدَّث باستمرار من قراءات ميدانية موسومة بالزمن، مع معالجة صريحة للبيانات الناقصة أو " +
            "المشوّشة خارج نطاق تغطية RFID، و(3) خوارزمية ميتاهيوريستيك هجينة تجمع بين NSGA-II " +
            "وتحسين محلي (2-opt) لإنتاج حلول قريبة من المثالية (Pareto) ضمن زمن حوسبي معقول."
    ),
    ThesisSection(
        "الحل المقترح (النموذج والخوارزمية)",
        "النموذج الرياضي يهدف لتقليل هدفين في آن: (Z1) التكلفة اللوجستية الإجمالية (تكاليف فتح " +
            "المرافق + تكاليف النقل)، و(Z2) زمن التسليم \"المستنَد إلى RFID\"، مع قيود السعة، تغطية " +
            "RFID، استمرارية المسار، وأقصى مسافة/زمن خدمة. تُرمَّز الحلول (الكروموسوم) كمجموعة من " +
            "المرافق المفتوحة، ثم يُخصَّص كل عميل لأقرب مرفق مفتوح، وتُبنى مسارات المركبات مقيّدة " +
            "بالسعة. تستخدم الخوارزمية الفرز غير المهيمَن السريع (Fast Non-dominated Sorting) ومسافة " +
            "الازدحام (Crowding Distance) للحفاظ على تنوّع جبهة باريتو عبر الأجيال المتعاقبة، بحيث " +
            "تتطور مجموعة الحلول تدريجيًا نحو التوازن الأمثل بين التكلفة وزمن التسليم."
    ),
    ThesisSection(
        "معاملات التجربة الرئيسية (الجدول 4-3)",
        "حالة الأساس: 8 مرافق مرشّحة و40 عميلاً. معاملات الخوارزمية: حجم مجتمع الحلول N=60، " +
            "أقصى عدد أجيال Gmax=150، احتمال التقاطع pc=0.90، احتمال الطفرة لكل جين pm=0.05، معدّل " +
            "تطبيق البحث المحلي (2-opt) = 0.30، سعة المركبة Q=120 وحدة، معامل التنعيم الأُسّي لبيانات " +
            "RFID λ=0.30، وبذرة عشوائية ثابتة. أُجريت خمس تجارب على حالة الأساس: التشغيل الرئيسي " +
            "(الخوارزمية الهجينة الكاملة)، تجربة دون بحث محلي (لعزل أثره)، تجربة أحادية الهدف (تكلفة " +
            "فقط)، تجربة دون بيانات RFID (زمن سفر ثابت بالمسافة فقط)، وتجربة قابلية التوسّع على ثلاث " +
            "أحجام مسألة (5 مرافق/15 عميلاً، 8/40، 12 مرفقًا/80 عميلاً)."
    ),
    ThesisSection(
        "أبرز النتائج",
        "على حالة أساس مكوّنة من 8 مرافق مرشّحة و40 عميلاً، أنتجت الخوارزمية جبهة باريتو متنوعة من " +
            "الحلول غير المهيمَن عليها. تبيّن أن إغفال بيانات RFID عن النموذج يؤدي إلى تقدير زمن " +
            "تسليم أقل من الواقع بنحو 12.6٪ مقارنة بالأداء الفعلي المرصود عبر RFID. كما أظهر التحليل " +
            "أن الخوارزمية الهجينة (NSGA-II + بحث محلي) تصل لجودة حل أعلى (مؤشر Hypervolume) بأجيال " +
            "أقل مقارنة بـNSGA-II المجرّدة. وعند المقارنة بخوارزمية أحادية الهدف (تكلفة فقط)، توفّر " +
            "النسخة متعددة الأهداف نطاقًا أوسع من الحلول يكشف مفاضلات تكلفة/زمن غير ظاهرة في النهج " +
            "أحادي الهدف. أما تحليل قابلية التوسّع فأظهر زمن حوسبة معتدل النمو (من 2.1 إلى 7.2 ثانية) " +
            "عبر أحجام مسألة من 5 مرافق/15 عميلاً حتى 12 مرفقًا/80 عميلاً."
    ),
    ThesisSection(
        "المقارنة مع الدراسات السابقة",
        "تتفق النتائج مع Sarac et al. (2010) وLim et al. (2013) في أن فوائد RFID الموثّقة تتركّز " +
            "في دقة التتبّع وظهور المخزون أكثر من قرارات التوجيه؛ وتضيف هذه الأطروحة قياسًا كميًا لما " +
            "يُفقَد عند إغفال ذلك (فجوة 12.6٪). وتتفق مع Ustundag & Cevikcan (2008) في أن دمج RFID " +
            "يغيّر مقاييس الأداء المرتبطة بالتوجيه، لكنها توسّع ذلك من مسألة توجيه أحادية المستوى إلى " +
            "مسألة متكاملة متعددة الأهداف. وتتفق مع Heidari (2023) وZhang (2014) وFarahani (2013) في " +
            "التوجّه نحو الدمج المشترك لقرارات الموقع والتوجيه، لكنها تتميّز بدمج بيانات RFID اللحظية " +
            "بدل معاملة تكاليف التوجيه كثابتة. وتتفق مع أطر باريتو لدى Amin-Tahmasbi (2023) وDeb et " +
            "al. (2002) في كشف مفاضلات التكلفة/الخدمة. وتتفق مع Archetti (2012) وHayat (2023) في " +
            "تفوّق الخوارزميات الهجينة على الخوارزمية الواحدة. الفارق الجوهري: لا توجد دراسة سابقة " +
            "جمعت بين بيانات RFID اللحظية ونموذج LRP متكامل متعدد الأهداف يُحل بخوارزمية هجينة — وهنا " +
            "تكمن مساهمة هذه الأطروحة تحديدًا."
    ),
    ThesisSection(
        "محدّدات (قيود) البحث",
        "• بيانات اصطناعية: لا توجد مجموعة بيانات عامة تجمع بيانات المرافق والطلب وقراءات RFID معًا، " +
            "فاستُخدمت بيانات مولَّدة اصطناعيًا. • فترة تخطيط واحدة وطلب حتمي (غير ديناميكي عبر الزمن). " +
            "• لم يُجرَ تحقق مقابل حل دقيق (Exact Solver) على نطاق واقعي. • اختبار قابلية التوسّع " +
            "محدود بثلاثة أحجام فقط (حتى 12 مرفقًا/80 عميلاً). • استُخدمت بذرة عشوائية واحدة ومجموعة " +
            "معاملات واحدة دون تحليل حساسية منهجي. • أسطول مركبات متجانس دون نوافذ زمنية أو قيود ساعات " +
            "عمل السائقين."
    ),
    ThesisSection(
        "مقترحات للبحث المستقبلي",
        "التحقق على بيانات RFID حقيقية أو هجينة من شبكة توزيع فعلية؛ التوسّع لنموذج متعدد الفترات أو " +
            "متجدد الأفق يُعاد فيه تحسين التوجيه دوريًا مع تحديث بيانات RFID؛ إجراء مقارنة رسمية مع " +
            "حلول دقيقة (Exact) على حالات صغيرة لقياس فجوة الأمثلية؛ دراسات حساسية منهجية لمعامل " +
            "التنعيم الأُسّي ومعدل البحث المحلي ومعاملات الخوارزمية الجينية؛ دراسة حوسبية أكبر نطاقًا " +
            "(مئات المرافق/العملاء)؛ إضافة أهداف وقيود إضافية (تكلفة بيئية، نوافذ زمنية، أسطول غير " +
            "متجانس)؛ ومقارنة الخوارزمية المقترحة بخوارزميات ميتاهيوريستيك بديلة مثل MOEA/D أو SPEA2."
    )
)

private val persianSections = listOf(
    ThesisSection(
        "عنوان پایان‌نامه",
        "رویکردی مبتنی بر فناوری RFID و الگوریتم‌های هوشمند برای ردیابی محصولات و حل مسئله " +
            "مکان‌یابی و مسیریابی وسایل نقلیه (Location-Routing Problem – LRP) در شبکه‌های توزیع و " +
            "زنجیره تأمین."
    ),
    ThesisSection(
        "مسئله پژوهش",
        "با گسترش شبکه‌های توزیع و پیچیدگی روزافزون زنجیره تأمین، تصمیمات حمل‌ونقل دیگر فقط به " +
            "جابه‌جایی کالا از تأمین‌کننده به مشتری محدود نمی‌شود، بلکه شامل مکان‌یابی تسهیلات، تخصیص " +
            "مشتریان و مسیریابی وسایل نقلیه به‌طور هم‌زمان است. بیشتر مدل‌های سنتی LRP بر تخمین‌های " +
            "ثابت زمان سفر (صرفاً بر پایه مسافت) تکیه دارند و داده‌های ردیابی لحظه‌ای حاصل از RFID را " +
            "در فرایند تصمیم‌گیری لحاظ نمی‌کنند. پرسش اصلی: چگونه می‌توان اطلاعات ردیابی محصول که از " +
            "طریق RFID تولید می‌شود را با مسئله مکان‌یابی-مسیریابی چندهدفه و یک رویکرد بهینه‌سازی " +
            "هوشمند ترکیب کرد تا هزینه لجستیکی، کارایی ردیابی و عملکرد تحویل بهبود یابد؟"
    ),
    ThesisSection(
        "اهمیت پژوهش",
        "اهمیت این پژوهش از پنج بُعد قابل بررسی است: علمی (پیوند حوزه‌های مستقل RFID، دیده‌پذیری " +
            "زنجیره تأمین، مکان‌یابی، مسیریابی، بهینه‌سازی چندهدفه و الگوریتم‌های هوشمند)، فناورانه " +
            "(افزایش ارزش عملیاتی RFID از طریق زنجیره: گردآوری داده ← پردازش ← بهینه‌سازی ← تصمیم " +
            "هوشمند)، اقتصادی (لحاظ‌کردن هزینه احداث تسهیلات، حمل‌ونقل، بهره‌برداری از وسایل نقلیه و " +
            "پیاده‌سازی RFID)، مدیریتی (ارائه چارچوب پشتیبان تصمیم برای مدیران زنجیره تأمین)، و " +
            "محاسباتی (پاسخ به پیچیدگی حل دقیق مسئله LRP چندهدفه از طریق الگوریتم‌های هوشمند)."
    ),
    ThesisSection(
        "اهداف پژوهش",
        "هدف اصلی: توسعه یک چارچوب بهینه‌سازی هوشمند مبتنی بر RFID برای ردیابی محصول و حل مسئله " +
            "مکان‌یابی-مسیریابی چندهدفه. از اهداف فرعی می‌توان به موارد زیر اشاره کرد: بررسی نقش RFID " +
            "در بهبود ردیابی و دیده‌پذیری زنجیره تأمین؛ تبدیل داده‌های RFID به ورودی‌های بهینه‌سازی؛ " +
            "فرمول‌بندی مدل ریاضی مسئله؛ تعیین هم‌زمان مکان تسهیلات، تخصیص مشتریان و مسیرهای وسایل " +
            "نقلیه؛ کمینه‌سازی هزینه کل لجستیکی و زمان تحویل همراه با بیشینه‌سازی کارایی ردیابی؛ لحاظ " +
            "محدودیت‌های عملی (ظرفیت وسایل نقلیه، ظرفیت تسهیلات، پوشش RFID)؛ توسعه یک روش حل هوشمند/ " +
            "فراابتکاری؛ و ارزیابی و مقایسه عملکرد آن با روش‌های مرجع در سناریوهای گوناگون."
    ),
    ThesisSection(
        "ابزار و روش‌شناسی",
        "روش پژوهش، تحلیلی/مدل‌سازی است: مسئله به‌صورت یک برنامه ریاضی عدد صحیح مختلط چندهدفه " +
            "فرمول‌بندی شده و یک الگوریتم حل اختصاصی برای آن توسعه یافته است. مدل شامل سه بخش است: " +
            "(۱) مدل ریاضی برای شبکه توزیع دوسطحی (تسهیلات نامزد ← مشتریان)، (۲) مکانیزم پردازشی که " +
            "رویدادهای خام قرائت برچسب RFID را از طریق قاعده هموارسازی نمایی (Exponential Smoothing) " +
            "به پارامتر «زمان سفر» تبدیل می‌کند و داده‌های ناقص یا نویزی خارج از محدوده پوشش را نیز " +
            "به‌صراحت مدیریت می‌کند، و (۳) الگوریتم فراابتکاری ترکیبی شامل NSGA-II به‌همراه جست‌وجوی " +
            "محلی (2-opt) برای تولید راه‌حل‌های نزدیک به پارتو در زمان محاسباتی معقول."
    ),
    ThesisSection(
        "راه‌حل پیشنهادی (مدل و الگوریتم)",
        "مدل ریاضی دو هدف را هم‌زمان کمینه می‌کند: (Z1) هزینه کل لجستیکی (هزینه افتتاح تسهیلات + " +
            "هزینه حمل‌ونقل) و (Z2) زمان تحویل «مبتنی بر RFID»، همراه با محدودیت‌های ظرفیت، پوشش " +
            "RFID، پیوستگی مسیر و حداکثر مسافت/زمان خدمت. هر راه‌حل (کروموزوم) به‌صورت مجموعه‌ای از " +
            "تسهیلات باز کدگذاری می‌شود؛ سپس هر مشتری به نزدیک‌ترین تسهیل باز تخصیص می‌یابد و مسیرهای " +
            "وسایل نقلیه با رعایت ظرفیت ساخته می‌شوند. الگوریتم از مرتب‌سازی سریع نامغلوب (Fast " +
            "Non-dominated Sorting) و فاصله ازدحام (Crowding Distance) برای حفظ تنوع جبهه پارتو در " +
            "طول نسل‌ها استفاده می‌کند."
    ),
    ThesisSection(
        "پارامترهای اصلی آزمایش (جدول ۴-۳)",
        "نمونه پایه: ۸ تسهیل نامزد و ۴۰ مشتری. پارامترهای الگوریتم: اندازه جمعیت N=۶۰، حداکثر " +
            "نسل Gmax=۱۵۰، احتمال تقاطع pc=۰.۹۰، احتمال جهش هر ژن pm=۰.۰۵، نرخ اعمال جست‌وجوی محلی " +
            "(2-opt) = ۰.۳۰، ظرفیت وسیله نقلیه Q=۱۲۰ واحد، پارامتر هموارسازی نمایی RFID λ=۰.۳۰، و " +
            "یک بذر تصادفی ثابت. پنج آزمایش روی نمونه پایه انجام شد: اجرای اصلی (الگوریتم ترکیبی " +
            "کامل)، آزمایش بدون جست‌وجوی محلی (برای انزوای اثر آن)، آزمایش تک‌هدفه (فقط هزینه)، " +
            "آزمایش بدون داده RFID (زمان سفر ثابت بر پایه مسافت)، و آزمایش مقیاس‌پذیری روی سه اندازه " +
            "مسئله (۵ تسهیل/۱۵ مشتری، ۸/۴۰، ۱۲ تسهیل/۸۰ مشتری)."
    ),
    ThesisSection(
        "مهم‌ترین نتایج",
        "روی نمونه پایه با ۸ تسهیل نامزد و ۴۰ مشتری، الگوریتم یک جبهه پارتو متنوع از راه‌حل‌های " +
            "نامغلوب تولید کرد. مشخص شد که حذف داده‌های RFID از مدل باعث می‌شود زمان تحویل حدود " +
            "۱۲.۶٪ کمتر از مقدار واقعی مشاهده‌شده توسط RFID برآورد شود. همچنین الگوریتم ترکیبی " +
            "(NSGA-II + جست‌وجوی محلی) با نسل‌های کمتری به کیفیت راه‌حل بالاتر (شاخص Hypervolume) " +
            "می‌رسد. در مقایسه با الگوریتم تک‌هدفه (فقط هزینه)، نسخه چندهدفه طیف وسیع‌تری از " +
            "راه‌حل‌ها را آشکار می‌کند که مصالحه‌های هزینه/زمان پنهان در رویکرد تک‌هدفه را نشان می‌دهد. " +
            "تحلیل مقیاس‌پذیری نیز رشد متعادل زمان محاسبه (از ۲.۱ تا ۷.۲ ثانیه) را در ابعاد مختلف " +
            "مسئله (از ۵ تسهیل/۱۵ مشتری تا ۱۲ تسهیل/۸۰ مشتری) نشان داد."
    ),
    ThesisSection(
        "مقایسه با پژوهش‌های پیشین",
        "نتایج با Sarac و همکاران (۲۰۱۰) و Lim و همکاران (۲۰۱۳) هم‌راستاست که فواید مستند RFID " +
            "بیشتر در دقت ردیابی و دیده‌پذیری موجودی متمرکز است تا در تصمیمات مسیریابی؛ این پایان‌نامه " +
            "میزان این فقدان را به‌صورت کمّی (شکاف ۱۲.۶٪) نشان می‌دهد. با Ustundag و Cevikcan (۲۰۰۸) " +
            "هم‌راستاست که ادغام RFID شاخص‌های عملکرد مسیریابی را تغییر می‌دهد، اما این یافته را از یک " +
            "مسئله تک‌سطحی به یک مدل یکپارچه چندهدفه گسترش می‌دهد. با Heidari (۲۰۲۳)، Zhang (۲۰۱۴) و " +
            "Farahani (۲۰۱۳) هم‌راستاست در گرایش به یکپارچه‌سازی مکان‌یابی و مسیریابی، اما با تفاوت " +
            "ادغام داده لحظه‌ای RFID به‌جای فرض ثابت‌بودن هزینه مسیریابی. با چارچوب‌های پارتوی " +
            "Amin-Tahmasbi (۲۰۲۳) و Deb و همکاران (۲۰۰۲) هم‌راستاست در آشکارسازی مصالحه هزینه/خدمت. " +
            "با Archetti (۲۰۱۲) و Hayat (۲۰۲۳) هم‌راستاست در برتری الگوریتم‌های ترکیبی. تفاوت اصلی: " +
            "هیچ پژوهش پیشین داده لحظه‌ای RFID را با یک مدل یکپارچه چندهدفه LRP حل‌شده با الگوریتم " +
            "ترکیبی جمع نکرده است — و این دقیقاً سهم این پایان‌نامه است."
    ),
    ThesisSection(
        "محدودیت‌های پژوهش",
        "• داده مصنوعی: هیچ مجموعه‌داده عمومی، داده تسهیلات، تقاضا و قرائت RFID را با هم ترکیب " +
            "نمی‌کند، بنابراین از داده مصنوعی استفاده شد. • یک دوره برنامه‌ریزی و تقاضای قطعی (بدون " +
            "پویایی زمانی). • عدم اعتبارسنجی در برابر حل دقیق (Exact) در مقیاس واقعی. • آزمون " +
            "مقیاس‌پذیری محدود به سه اندازه (حداکثر ۱۲ تسهیل/۸۰ مشتری). • استفاده از یک بذر تصادفی و " +
            "یک مجموعه پارامتر ثابت بدون تحلیل حساسیت نظام‌مند. • ناوگان همگن بدون پنجره زمانی یا " +
            "محدودیت ساعت کاری راننده."
    ),
    ThesisSection(
        "پیشنهادها برای پژوهش آینده",
        "اعتبارسنجی روی داده RFID واقعی یا ترکیبی از یک شبکه توزیع واقعی؛ گسترش به مدل چنددوره‌ای یا " +
            "افق غلتان که مسیریابی به‌طور دوره‌ای با داده‌های تازه RFID بازبهینه شود؛ مقایسه رسمی با " +
            "حل دقیق روی نمونه‌های کوچک برای اندازه‌گیری شکاف بهینگی؛ مطالعات حساسیت نظام‌مند برای " +
            "پارامتر هموارسازی، نرخ جست‌وجوی محلی و پارامترهای الگوریتم ژنتیک؛ مطالعه محاسباتی در " +
            "مقیاس بزرگ‌تر (صدها تسهیل/مشتری)؛ افزودن اهداف و محدودیت‌های بیشتر (هزینه زیست‌محیطی، " +
            "پنجره زمانی، ناوگان ناهمگن)؛ و مقایسه با فراابتکاری‌های جایگزین مانند MOEA/D یا SPEA2."
    )
)

private val englishSections = listOf(
    ThesisSection(
        "Thesis Title",
        "An RFID-Based and Intelligent Algorithm Approach for Product Tracking and Solving the " +
            "Vehicle Location-Routing Problem (LRP) in distribution and supply-chain networks."
    ),
    ThesisSection(
        "Research Problem",
        "As distribution networks expand and supply chains grow more complex, transportation " +
            "decisions no longer involve simply moving products from supplier to customer; " +
            "organizations must jointly decide facility locations, customer allocation, and vehicle " +
            "routing. Most conventional Location-Routing models rely on static, distance-based " +
            "travel-time estimates and do not incorporate the real-time tracking data that RFID can " +
            "provide into the decision process. Central question: how can RFID-generated product " +
            "tracking information be integrated with a multi-objective Location-Routing Problem and " +
            "an intelligent optimization approach to improve logistics cost, tracking efficiency, and " +
            "delivery performance?"
    ),
    ThesisSection(
        "Significance of the Research",
        "The study's value spans five dimensions: scientific (linking previously separate fields — " +
            "RFID identification, supply-chain visibility, facility location, vehicle routing, " +
            "multi-objective optimization, and intelligent algorithms); technological (raising RFID's " +
            "operational value through a data-acquisition → processing → optimization → decision " +
            "pipeline); economic (jointly considering facility, transport, vehicle-operation, and RFID " +
            "implementation costs); managerial (providing a decision-support framework for supply-" +
            "chain managers); and computational (addressing the combinatorial difficulty of solving a " +
            "multi-objective LRP exactly, motivating an intelligent metaheuristic approach)."
    ),
    ThesisSection(
        "Research Objectives",
        "Main objective: to develop an RFID-enabled intelligent optimization framework for product " +
            "tracking and the multi-objective Location-Routing Problem. Specific objectives include: " +
            "examining RFID's role in improving tracking and supply-chain visibility; converting RFID " +
            "data into optimization inputs; formulating a mathematical model of the problem; jointly " +
            "determining facility locations, customer assignments, and vehicle routes; minimizing " +
            "total logistics cost and delivery time while maximizing tracking efficiency; " +
            "incorporating practical constraints (vehicle and facility capacity, RFID coverage); " +
            "developing an intelligent/metaheuristic solution method; and evaluating and benchmarking " +
            "its performance across different scenarios."
    ),
    ThesisSection(
        "Tools and Methodology",
        "An analytical/modeling research method is adopted: the problem is formalized as a mixed-" +
            "integer, multi-objective mathematical program, paired with a purpose-built solution " +
            "algorithm. The method has three components: (1) a mathematical model of a two-echelon " +
            "distribution network (candidate facilities → customers); (2) a data-processing mechanism " +
            "that converts raw RFID tag-read events into the travel-time parameter via an exponential-" +
            "smoothing update rule, explicitly handling missing or noisy data outside RFID coverage; " +
            "and (3) a hybrid metaheuristic combining NSGA-II with local-search (2-opt) refinement to " +
            "generate near-Pareto-optimal solutions within practical computation time."
    ),
    ThesisSection(
        "Proposed Solution (Model and Algorithm)",
        "The mathematical model minimizes two objectives simultaneously: (Z1) total logistics cost " +
            "(facility-opening + transportation cost) and (Z2) RFID-informed delivery time, subject " +
            "to capacity, RFID-coverage, route-continuity, and maximum-distance/service-time " +
            "constraints. Each solution (chromosome) is encoded as a set of open facilities; customers " +
            "are then assigned to their nearest open facility, and vehicle routes are built under " +
            "capacity limits. The algorithm uses fast non-dominated sorting and crowding distance to " +
            "preserve Pareto-front diversity across generations."
    ),
    ThesisSection(
        "Main Experimental Parameters (Table 4-3)",
        "Base instance: 8 candidate facilities and 40 customers. Algorithm parameters: population " +
            "size N=60, maximum generations Gmax=150, crossover probability pc=0.90, per-gene " +
            "mutation probability pm=0.05, 2-opt local-search application rate=0.30, vehicle capacity " +
            "Q=120 units, RFID exponential-smoothing parameter λ=0.30, and a fixed random seed. Five " +
            "experiments were run on the base instance: the main run (full hybrid algorithm), a no-" +
            "local-search variant (to isolate its contribution), a single-objective (cost-only) " +
            "variant, a no-RFID variant (static distance-based travel time), and a scalability " +
            "experiment across three instance sizes (5 facilities/15 customers, 8/40, 12 facilities/" +
            "80 customers)."
    ),
    ThesisSection(
        "Key Findings",
        "On a base instance of 8 candidate facilities and 40 customers, the algorithm produced a " +
            "diverse Pareto front of non-dominated solutions. Omitting RFID-informed travel time from " +
            "the model was found to understate actual delivery time by approximately 12.6% relative to " +
            "RFID-observed conditions. The hybrid algorithm (NSGA-II + local search) reached a higher " +
            "hypervolume in fewer generations than plain NSGA-II. Compared with a single-objective " +
            "(cost-only) baseline, the multi-objective version reveals a wider range of cost/delivery-" +
            "time trade-offs the single-objective approach cannot access. Scalability analysis showed " +
            "moderate computation-time growth (2.1 to 7.2 seconds) across instance sizes from 5 " +
            "facilities/15 customers up to 12 facilities/80 customers."
    ),
    ThesisSection(
        "Comparison with Previous Studies",
        "Consistent with Sarac et al. (2010) and Lim et al. (2013), who found RFID's documented " +
            "benefits concentrated in tracking accuracy and inventory visibility rather than routing, " +
            "this thesis quantifies what is lost by not capturing that (the 12.6% delivery-time gap). " +
            "Consistent with Ustundag & Cevikcan (2008), RFID integration is found to change routing-" +
            "relevant performance measures, here extended from a single-echelon routing problem to an " +
            "integrated multi-objective LRP. Consistent with Heidari (2023), Zhang (2014), and Farahani " +
            "(2013) on jointly optimizing location and routing decisions, this work differs by " +
            "embedding real-time RFID data rather than treating routing costs as static. Consistent " +
            "with the Pareto-based frameworks of Amin-Tahmasbi (2023) and Deb et al. (2002), a multi-" +
            "objective formulation is shown to reveal cost-service trade-offs a single-objective model " +
            "cannot. Consistent with Archetti (2012) and Hayat (2023), the hybrid algorithm outperforms " +
            "a single-algorithm approach. The key point of divergence: no prior study combines RFID-" +
            "informed real-time data with an integrated multi-objective LRP solved by a hybrid " +
            "metaheuristic — which is precisely this thesis's contribution."
    ),
    ThesisSection(
        "Limitations",
        "• Synthetic dataset: no public dataset combines facility, demand, and RFID-observed travel-" +
            "time data, so a synthetic instance was generated. • Single-period, deterministic setting " +
            "(no time-varying demand). • No exact-solution validation at realistic scale. • Scalability " +
            "testing limited to three instance sizes (up to 12 facilities/80 customers). • A single " +
            "random seed and one parameter set, without formal sensitivity analysis. • Homogeneous " +
            "vehicle fleet, no time windows or driver working-hour constraints."
    ),
    ThesisSection(
        "Suggestions for Future Research",
        "Validating the model on real or hybrid RFID-LRP data from an operational network; extending " +
            "to a multi-period or rolling-horizon formulation with periodic re-optimization as new RFID " +
            "observations arrive; formal benchmarking against exact solvers on small instances to " +
            "quantify the optimality gap; systematic sensitivity analysis of the smoothing parameter, " +
            "local-search rate, and GA parameters; a larger-scale computational study (hundreds of " +
            "facilities/customers); adding objectives and constraints (environmental cost, time " +
            "windows, heterogeneous fleets); and comparing against alternative metaheuristics such as " +
            "MOEA/D or SPEA2."
    )
)

fun thesisSections(language: com.arak.rfidlrp.i18n.AppLanguage): List<ThesisSection> = when (language) {
    com.arak.rfidlrp.i18n.AppLanguage.ARABIC -> arabicSections
    com.arak.rfidlrp.i18n.AppLanguage.PERSIAN -> persianSections
    com.arak.rfidlrp.i18n.AppLanguage.ENGLISH -> englishSections
}
