package com.arak.rfidlrp.model

data class Facility(
    val id: Int,
    val x: Double,
    val y: Double,
    val capacity: Int,
    val openingCost: Double
)

data class Customer(
    val id: Int,
    val x: Double,
    val y: Double,
    val demand: Int
)

data class RfidEvent(
    val tagId: String,
    val productCode: String,
    val nodeLabel: String,
    val timestampMs: Long,
    val signalStrength: Int // 0-100
)

data class VehicleRoute(
    val vehicleId: Int,
    val facilityId: Int,
    val stops: List<Int>, // معرّفات العملاء بترتيب الزيارة
    val distance: Double,
    val travelTime: Double,
    val load: Int
)

data class Solution(
    val openFacilities: Set<Int>,
    val assignment: Map<Int, Int>, // customerId -> facilityId
    val routes: List<VehicleRoute>,
    val totalCost: Double,          // Z1: التكلفة اللوجستية الإجمالية
    val totalTime: Double,          // Z2: زمن التسليم المستنَد إلى RFID
    val trackingEfficiency: Double, // كفاءة تتبّع المنتجات (0..1)
    var rank: Int = 0,
    var crowdingDistance: Double = 0.0
)

data class ProblemInstance(
    val facilities: List<Facility>,
    val customers: List<Customer>,
    val vehicleCapacity: Int,
    val speed: Double,
    val serviceTime: Double,
    val costPerDistance: Double,
    val rfidCoverageRadius: Double
)
