package com.arak.rfidlrp.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.arak.rfidlrp.AppViewModel
import com.arak.rfidlrp.i18n.LocalAppStrings
import com.arak.rfidlrp.model.RfidEvent
import com.arak.rfidlrp.model.RfidEventType
import com.arak.rfidlrp.model.RfidNodeKind
import com.arak.rfidlrp.ui.components.AppTopBar
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RfidScreen(nav: NavController, vm: AppViewModel) {
    val strings = LocalAppStrings.current
    val events by vm.rfidEvents.collectAsState()
    val running by vm.rfidRunning.collectAsState()
    val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    Scaffold(topBar = { AppTopBar(strings.rfidTitle, onBack = { nav.popBackStack() }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Row {
                Button(onClick = { vm.toggleRfidSimulation() }) {
                    Text(if (running) strings.rfidStop else strings.rfidStart)
                }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = { vm.clearRfidEvents() }) {
                    Text(strings.rfidClear)
                }
            }

            if (events.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                val avgSignal = events.map { it.signalStrength }.average().toInt()
                val coveragePct = (events.count { it.signalStrength >= 55 } * 100 / events.size)
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(10.dp)) {
                        Text(strings.rfidStatsCount.format(events.size), modifier = Modifier.weight(1f))
                        Text(strings.rfidStatsAvgSignal.format(avgSignal), modifier = Modifier.weight(1f))
                        Text(strings.rfidStatsCoverage.format(coveragePct), modifier = Modifier.weight(1f))
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            LazyColumn(Modifier.fillMaxSize()) {
                items(events.size) { i ->
                    val e = events[i]
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Column(Modifier.padding(10.dp)) {
                            Text("${e.tagId} — ${e.productCode}", fontWeight = FontWeight.Bold)
                            Text(eventLabel(e, strings))
                            Text(strings.rfidSignalLabel.format(e.signalStrength, fmt.format(Date(e.timestampMs))))
                        }
                    }
                }
            }
        }
    }
}

private fun eventLabel(e: RfidEvent, strings: com.arak.rfidlrp.i18n.AppStrings): String {
    val action = if (e.eventType == RfidEventType.PICKUP) strings.rfidPickup else strings.rfidDelivery
    val node = if (e.nodeKind == RfidNodeKind.FACILITY) strings.rfidFacilityNode else strings.rfidCustomerNode
    val vehiclePart = e.vehicleId?.let { " (${strings.rfidVehicleSuffix.format(it)})" } ?: ""
    return "$action — $node #${e.nodeId}$vehiclePart"
}
