package com.arak.rfidlrp.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.arak.rfidlrp.AppViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RfidScreen(nav: NavController, vm: AppViewModel) {
    val events by vm.rfidEvents.collectAsState()
    val running by vm.rfidRunning.collectAsState()
    val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("محاكاة قراءات RFID الحيّة", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Button(onClick = { vm.toggleRfidSimulation() }) {
            Text(if (running) "إيقاف المحاكاة" else "بدء المحاكاة")
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.fillMaxSize()) {
            items(events.size) { i ->
                val e = events[i]
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text("${e.tagId} — ${e.productCode}")
                        Text("عند: ${e.nodeLabel}")
                        Text("قوة الإشارة: ${e.signalStrength}%  •  ${fmt.format(Date(e.timestampMs))}")
                    }
                }
            }
        }
    }
}
