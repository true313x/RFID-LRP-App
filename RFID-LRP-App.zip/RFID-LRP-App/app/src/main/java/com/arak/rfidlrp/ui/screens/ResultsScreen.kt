package com.arak.rfidlrp.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.arak.rfidlrp.AppViewModel
import com.arak.rfidlrp.i18n.AppStrings
import com.arak.rfidlrp.i18n.LocalAppStrings
import com.arak.rfidlrp.model.Solution
import com.arak.rfidlrp.ui.components.AppTopBar

@Composable
fun ResultsScreen(nav: NavController, vm: AppViewModel) {
    val strings = LocalAppStrings.current
    val pareto by vm.paretoFront.collectAsState()

    Scaffold(topBar = { AppTopBar(strings.resultsTitle, onBack = { nav.popBackStack() }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(strings.resultsChartTitle, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            ParetoChart(pareto, strings, Modifier.fillMaxWidth().height(240.dp))
            Spacer(Modifier.height(16.dp))
            Text(strings.resultsCount.format(pareto.size))
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.fillMaxSize()) {
                items(pareto.size) { i ->
                    val s = pareto[i]
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        onClick = { nav.navigate("solution/$i") }
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(strings.resultsSolutionPrefix.format(i + 1), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                            Text(strings.resultsOpenFacilities.format(s.openFacilities.sorted().joinToString(", ")))
                            Text(strings.resultsCost.format("%.1f".format(s.totalCost)))
                            Text(strings.resultsTime.format("%.1f".format(s.totalTime)))
                            Text(strings.resultsTracking.format("%.0f".format(s.trackingEfficiency * 100)))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ParetoChart(solutions: List<Solution>, strings: AppStrings, modifier: Modifier = Modifier) {
    val textMeasurer = rememberTextMeasurer()
    Card(modifier = modifier) {
        Canvas(modifier = Modifier.fillMaxSize().padding(12.dp)) {
            if (solutions.isEmpty()) return@Canvas
            val minCost = solutions.minOf { it.totalCost }
            val maxCost = solutions.maxOf { it.totalCost }
            val minTime = solutions.minOf { it.totalTime }
            val maxTime = solutions.maxOf { it.totalTime }
            val costRange = (maxCost - minCost).takeIf { it > 0 } ?: 1.0
            val timeRange = (maxTime - minTime).takeIf { it > 0 } ?: 1.0

            val leftPad = 8f
            val bottomPad = 28f
            val topPad = 8f
            val rightPad = 8f
            val w = size.width - leftPad - rightPad
            val h = size.height - topPad - bottomPad

            val gridColor = Color(0xFF2C3E50).copy(alpha = 0.25f)
            for (i in 0..4) {
                val gy = topPad + h * i / 4f
                drawLine(gridColor, Offset(leftPad, gy), Offset(leftPad + w, gy), strokeWidth = 1f)
                val gx = leftPad + w * i / 4f
                drawLine(gridColor, Offset(gx, topPad), Offset(gx, topPad + h), strokeWidth = 1f)
            }
            drawLine(Color(0xFF546E7A), Offset(leftPad, topPad + h), Offset(leftPad + w, topPad + h), strokeWidth = 2f)
            drawLine(Color(0xFF546E7A), Offset(leftPad, topPad), Offset(leftPad, topPad + h), strokeWidth = 2f)

            val sorted = solutions.sortedBy { it.totalCost }
            for (k in 0 until sorted.size - 1) {
                val s1 = sorted[k]; val s2 = sorted[k + 1]
                val x1 = leftPad + ((s1.totalCost - minCost) / costRange).toFloat() * w
                val y1 = topPad + h - ((s1.totalTime - minTime) / timeRange).toFloat() * h
                val x2 = leftPad + ((s2.totalCost - minCost) / costRange).toFloat() * w
                val y2 = topPad + h - ((s2.totalTime - minTime) / timeRange).toFloat() * h
                drawLine(Color(0xFF90CAF9).copy(alpha = 0.6f), Offset(x1, y1), Offset(x2, y2), strokeWidth = 2f)
            }

            solutions.forEach { s ->
                val px = leftPad + ((s.totalCost - minCost) / costRange).toFloat() * w
                val py = topPad + h - ((s.totalTime - minTime) / timeRange).toFloat() * h
                val radius = 5f + (s.trackingEfficiency.toFloat() * 4f)
                drawCircle(color = Color(0xFF1565C0), radius = radius, center = Offset(px, py))
                drawCircle(
                    color = Color.White,
                    radius = radius,
                    center = Offset(px, py),
                    style = Stroke(width = 1.2f)
                )
            }

            val axisLayout = textMeasurer.measure(strings.resultsChartCostAxis)
            drawText(
                textMeasurer = textMeasurer,
                text = strings.resultsChartCostAxis,
                topLeft = Offset(leftPad + w / 2f - axisLayout.size.width / 2f, topPad + h + 10f)
            )
        }
    }
}
