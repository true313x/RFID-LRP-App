package com.arak.rfidlrp.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.arak.rfidlrp.AppViewModel
import com.arak.rfidlrp.i18n.LocalAppStrings
import com.arak.rfidlrp.ui.components.AppTopBar
import com.arak.rfidlrp.ui.components.ParetoScatterChart

@Composable
fun ResultsScreen(nav: NavController, vm: AppViewModel) {
    val strings = LocalAppStrings.current
    val pareto by vm.paretoFront.collectAsState()

    Scaffold(topBar = { AppTopBar(strings.resultsTitle, onBack = { nav.popBackStack() }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(strings.resultsChartTitle, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            ParetoScatterChart(
                solutions = pareto,
                costAxisLabel = strings.resultsChartCostAxis,
                timeAxisLabel = strings.resultsChartTimeAxis,
                modifier = Modifier.fillMaxWidth().height(260.dp)
            )
            Spacer(Modifier.height(16.dp))
            Text(strings.resultsCount.format(pareto.size))
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.fillMaxSize()) {
                items(pareto.size) { i ->
                    val s = pareto[i]
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        onClick = { nav.navigate("solution/$i") }
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(strings.resultsSolutionPrefix.format(i + 1), fontWeight = FontWeight.Bold)
                            Text(strings.resultsOpenFacilities.format(s.openFacilities.sorted().joinToString(", ")))
                            Text(strings.resultsCost.format("%.1f".format(s.totalCost)))
                            Text(strings.resultsTime.format("%.1f".format(s.totalTime)))
                            Text(strings.resultsTracking.format("%.0f".format(s.trackingEfficiency * 100)))
                        }
                    }
                }
            }
        }
    }
}
