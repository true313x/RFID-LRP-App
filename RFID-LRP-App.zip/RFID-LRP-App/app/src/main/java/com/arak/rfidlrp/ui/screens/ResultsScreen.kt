package com.arak.rfidlrp.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.arak.rfidlrp.AppViewModel
import com.arak.rfidlrp.model.Solution

@Composable
fun ResultsScreen(nav: NavController, vm: AppViewModel) {
    val pareto by vm.paretoFront.collectAsState()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("جبهة باريتو: التكلفة (Z1) مقابل زمن التسليم (Z2)", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        ParetoChart(pareto, Modifier.fillMaxWidth().height(220.dp))
        Spacer(Modifier.height(16.dp))
        Text("عدد الحلول غير المهيمَن عليها: ${pareto.size}")
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.fillMaxSize()) {
            items(pareto.size) { i ->
                val s = pareto[i]
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    onClick = { nav.navigate("solution/$i") }
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text("حل #${i + 1} — مرافق مفتوحة: ${s.openFacilities.sorted()}")
                        Text("التكلفة الإجمالية (Z1): ${"%.1f".format(s.totalCost)}")
                        Text("زمن التسليم (Z2): ${"%.1f".format(s.totalTime)}")
                        Text("كفاءة تتبّع RFID: ${"%.0f".format(s.trackingEfficiency * 100)}%")
                    }
                }
            }
        }
    }
}

@Composable
private fun ParetoChart(solutions: List<Solution>, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        if (solutions.isEmpty()) return@Canvas
        val minCost = solutions.minOf { it.totalCost }
        val maxCost = solutions.maxOf { it.totalCost }
        val minTime = solutions.minOf { it.totalTime }
        val maxTime = solutions.maxOf { it.totalTime }
        val costRange = (maxCost - minCost).takeIf { it > 0 } ?: 1.0
        val timeRange = (maxTime - minTime).takeIf { it > 0 } ?: 1.0

        val padding = 24f
        val w = size.width - padding * 2
        val h = size.height - padding * 2

        solutions.forEach { s ->
            val px = padding + ((s.totalCost - minCost) / costRange).toFloat() * w
            val py = size.height - padding - ((s.totalTime - minTime) / timeRange).toFloat() * h
            drawCircle(color = Color(0xFF1565C0), radius = 6f, center = Offset(px, py))
        }
    }
}
